//
//  ScrollDisplayViewController.h
//  BaseProject
//
//  Created by apple-jd21 on 15/10/31.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
//使用网路图片，需要引入 SDWebImage
#import <UIImageView+WebCache.h>
#import <UIButton+WebCache.h>

@class ScrollDisplayViewController;
@protocol ScrollDisplayViewControllerDelegate <NSObject>

@optional
//当用户点击了某一页触发
- (void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController didSelectedIndex:(NSInteger)index;

//实时回传当前的索引值
- (void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController currentIndex:(NSUInteger)index;

@end

@interface ScrollDisplayViewController : UIViewController{
    //成员变量
    NSTimer *_timer;
}

/*  初始化方法  */
//传入图片地址数组
- (instancetype)initWithImagePaths:(NSArray *)paths;
//传入图片名字数组
- (instancetype)initWithImageNames:(NSArray *)names;
//传入视图控制器
- (instancetype)initWithViewControllers:(NSArray *)controllers;

//设置只读的属性
@property (nonatomic, readonly) NSArray *paths;
@property (nonatomic, readonly) NSArray *names;
@property (nonatomic, readonly) NSArray *controllers;

//用于展示的控制器属性
@property (nonatomic, readonly) UIPageViewController *pageVC;
@property (nonatomic, readonly) UIPageControl *pageControl;


@property (nonatomic, weak) id<ScrollDisplayViewControllerDelegate> delegate;

//设置是否循环滚动，默认为YES，表示可以循环
@property (nonatomic) BOOL canCycle;
//设置是否定时滚动,默认为YES，表示定时滚动
@property (nonatomic) BOOL autoCycle;
//滚动时间,默认3秒
@property (nonatomic) NSTimeInterval duration;
//是否显示页数提示，默认YES,显示
@property (nonatomic) BOOL showPageControl;
//当前页数
@property (nonatomic) NSInteger currentPage;
//设置页数提示的垂直偏移量,正数表示先下移动
@property (nonatomic) CGFloat pageControlOffset;
//设置圆点的正常颜色, 默认黑色
@property (nonatomic, strong) UIColor *pageControlCurrentColor;
//设置圆点的高亮颜色 默认红色
@property (nonatomic, strong) UIColor *pageControlNormalColor;
//。。。。


@end
