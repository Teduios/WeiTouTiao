//
//  ScrollDisplayViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/10/31.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ScrollDisplayViewController.h"

@interface ScrollDisplayViewController ()<UIPageViewControllerDataSource, UIPageViewControllerDelegate>

@end

@implementation ScrollDisplayViewController

/*  初始化方法  */
//传入图片地址数组
- (instancetype)initWithImagePaths:(NSArray *)paths{
    
    //路径中可能的类型：NSURL HTTP:// https:// 本地路径:file://
    NSMutableArray *arr = [NSMutableArray new];
    for (int i = 0; i < paths.count; i++) {
        id path = paths[i];
//        UIImageView *imageView = [UIImageView new];
        //为了监控用户点击操作
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        if ([self isURL:path]) {
//            [imageView sd_setImageWithURL:path];
            [button sd_setBackgroundImageWithURL:path forState:0];
        }else if ([self isNetPath:path]){
            NSURL *url = [NSURL URLWithString:path];
//            [imageView sd_setImageWithURL:url];
            [button sd_setBackgroundImageWithURL:url forState:0];
        }else if([path isKindOfClass:[NSString class]]){
            //本地地址
            NSURL *url = [NSURL fileURLWithPath:path];
//            [imageView sd_setImageWithURL:url];
            [button sd_setBackgroundImageWithURL:url forState:0];
        }else{
            //这里可以给imageView 设置一个裂开的本地图片
//            imageView.image = [UIImage imageNamed:@"图片名称"];
            [button setImage:[UIImage imageNamed:@"图片名称"] forState:0];
        }
        UIViewController *vc = [UIViewController new];
//        vc.view = imageView;
        vc.view = button;
        //设置button的tag
        button.tag = 1000 + i;
        //给button添加点击事件
        [button bk_addEventHandler:^(UIButton *sender) {
            [self.delegate scrollDisplayViewController:self didSelectedIndex:sender.tag - 1000];
        } forControlEvents:UIControlEventTouchUpInside];
        
        [arr addObject:vc];
    }
    self = [self initWithViewControllers:arr];
    return self;
}

//判断路径的类型-----是否是URL
- (BOOL)isURL:(id)path{
    return [path isKindOfClass:[NSURL class]];
}
//判断路径的类型-----是否是网络地址
- (BOOL)isNetPath:(id)path{
    
    
    BOOL isStr = [path isKindOfClass:[NSString class]];
    //为了防止非String类型调用下方方法崩溃
    if (!isStr) {
        return NO;
    }
    BOOL contrainHttp = [path rangeOfString:@"http"].location != NSNotFound;
    BOOL contrainTile = [path rangeOfString:@"://"].location != NSNotFound;
    
    return isStr && contrainHttp && contrainTile;
}

//传入图片名字数组
- (instancetype)initWithImageNames:(NSArray *)names{
    //图片名字 -> Image ->ImageView -> ViewController
    NSMutableArray *arr = [NSMutableArray new];
    for (int i = 0; i < names.count; i++) {
//        UIImage *image = [UIImage imageNamed:names[i]];
//        UIImageView *imageView = [[UIImageView alloc]initWithImage:image];
//        UIViewController *vc = [UIViewController new];
//        vc.view = imageView;
//        [arr addObject:vc];
        //为了监听用户的点击操作,把图片换成按钮
        UIImage *image = [UIImage imageNamed:names[i]];
        UIButton *button = [UIButton buttonWithType:0];
        [button setBackgroundImage:image forState:0];
        UIViewController *vc = [UIViewController new];
        vc.view = button;
        button.tag = 1000+i;
        [button bk_addEventHandler:^(UIButton *sender) {
            [self.delegate scrollDisplayViewController:self didSelectedIndex:sender.tag - 1000];
        } forControlEvents:UIControlEventTouchUpInside];
        [arr addObject:vc];
        
    }
    //最终还是通过图片名获取到装有图片视图的控制器
    self = [self initWithViewControllers:arr];
    return self;
}
//传入视图控制器
- (instancetype)initWithViewControllers:(NSArray *)controllers{
    if (self = [super init]) {
        //为了防止实参是可变数组，需要复制一分出来，这样可以保证属性不会因为可变数组在外部被改变，而导致随之也改变
        _controllers = [controllers copy];
        
        //设置属性的默认值
        _autoCycle = YES;
        _canCycle = YES;
        _showPageControl = YES;
        _duration = 3;
        _pageControlOffset = 0;
        _pageControlCurrentColor = [UIColor redColor];
        _pageControlNormalColor = [UIColor blackColor];
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //如果控制器数组为空 或者什么都没有,就不需要任何操作
    if (_controllers.count == 0 || !_controllers) {
        return;
    }
    
    _pageVC = [[UIPageViewController alloc]initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
    _pageVC.delegate = self;
    _pageVC.dataSource = self;
    [self addChildViewController:_pageVC];
    [self.view addSubview:_pageVC.view];
    //需要使用pod，引入Masonry
    [_pageVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    //设置初始页面
    [_pageVC setViewControllers:@[_controllers.firstObject] direction:0 animated:YES completion:nil];
    
    //添加下方小圆点
    _pageControl = [UIPageControl new];
    _pageControl.numberOfPages = _controllers.count;
    [self.view addSubview:_pageControl];
    [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view);
        make.bottom.mas_equalTo(0);
    }];
    //去除小园点的用户操作事件
    _pageControl.userInteractionEnabled = NO;
    _pageControl.currentPageIndicatorTintColor = _pageControlCurrentColor;
    _pageControl.pageIndicatorTintColor = _pageControlNormalColor;
    
    self.autoCycle = _autoCycle;
    self.showPageControl = _showPageControl;
    self.pageControlOffset = _pageControlOffset;
    
}

#pragma  mark - UIPageViewControllerDataSource, UIPageViewControllerDelegate

//循环滚动
- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController{
    
    NSInteger index = [_controllers indexOfObject:viewController];
    if (index == 0) {
        return _canCycle ? _controllers.lastObject : nil;
    }
    return _controllers[index-1];
}

- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController{
    
    NSInteger index = [_controllers indexOfObject:viewController];
    if (index == _controllers.count - 1) {
        return _canCycle ? _controllers.firstObject : nil;
    }
    return _controllers[index+1];
}

- (void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray<UIViewController *> *)previousViewControllers transitionCompleted:(BOOL)completed{
    if (completed && finished) {
        [self configPageControl];
        NSInteger index = [self.controllers indexOfObject:pageViewController.viewControllers.firstObject];
        //respondsToSelector 可以判断 某个对象是否含有某个方法
        if ([self.delegate respondsToSelector:@selector(scrollDisplayViewController:currentIndex:)]) {
            [self.delegate scrollDisplayViewController:self currentIndex:index];
        }
    }
}

#pragma mark - 配置小圆点位置

- (void)configPageControl{
    //获取当前viewControl所显示的视图
    NSInteger index = [self.controllers indexOfObject:self.pageVC.viewControllers.firstObject];
    
    _pageControl.currentPage = index;
    
}

#pragma mark - 属性的setter方法

- (void)setAutoCycle:(BOOL)autoCycle{
    _autoCycle = autoCycle;
    
    //停止之前的计时器
    [_timer invalidate];
    if (!autoCycle) {//如果不需要自动循环，下方代码就不执行
        return;
    }
    
    _timer = [NSTimer bk_scheduledTimerWithTimeInterval:_duration block:^(NSTimer *timer) {
        UIViewController *vc = _pageVC.viewControllers.firstObject;
        NSInteger index = [_controllers indexOfObject:vc];
        UIViewController *nextVC = nil;
        if (index == _controllers.count - 1) {
            if (_canCycle == NO) {
                return ;
            }
            nextVC = _controllers.firstObject;
        }else{
            nextVC = _controllers[index+1];
        }
        __block id currentVC = self;
        [_pageVC setViewControllers:@[nextVC] direction:0 animated:YES completion:^(BOOL finished) {
            [currentVC configPageControl];
        }];
        
    } repeats:YES];
}

- (void)setShowPageControl:(BOOL)showPageControl{
    _showPageControl = showPageControl;
    
    _pageControl.hidden = !showPageControl;
}

- (void)setDuration:(NSTimeInterval)duration{
    _duration = duration;
    
    self.autoCycle = _autoCycle;
}

- (void)setPageControlOffset:(CGFloat)pageControlOffset{
    _pageControlOffset = pageControlOffset;
    
    //更新页面数量控件 bottom约束
    [_pageControl mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(_pageControlOffset);
    }];
}
- (void)setCurrentPage:(NSInteger)currentPage{
    /*
     设置新的新的显示页面，情况有三种：
     情况一：新页面 和 老页面 是同一个，什么都不做
     情况二：新页面 在 老页面 的右侧，动画效果应该是向右滚动
     情况三：新页面 在 老页面 的左侧，动画效果应该是向左滚动
     方向枚举值：
     。。。。。Forward =0  向右
     。。。。。Reverse =1  向左
     */
    NSInteger direction = 0;
    if (_currentPage == currentPage) {
        return;
    }else if(_currentPage > currentPage){
        direction = 1;
    }else{
        direction = 0;
    }
    _currentPage = currentPage;
    UIViewController *vc = _controllers[currentPage];
    [_pageVC setViewControllers:@[vc] direction:direction animated:YES completion:nil];
}

@end
