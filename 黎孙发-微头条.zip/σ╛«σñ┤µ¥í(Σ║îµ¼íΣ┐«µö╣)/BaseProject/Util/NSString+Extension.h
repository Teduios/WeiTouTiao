//
//  NSString+Extension.h
//  BaseProject
//
//  Created by apple－jd16 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
// 正文字体
#define LKWStatusCellContentFont [UIFont systemFontOfSize:16]

@interface NSString (Extension)
- (CGSize)sizeWithFont:(UIFont *)font maxW:(CGFloat)maxW;
- (CGSize)sizeWithFont:(UIFont *)font;
@end
