//
//  CommentModel.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class CommentExtModel,CommentDataModel,CommentDataSubcommentsModel;
@interface CommentModel : BaseModel

@property (nonatomic, assign) BOOL status;

@property (nonatomic, strong) NSArray<CommentDataModel *> *data;

@property (nonatomic, strong) CommentExtModel *ext;

@property (nonatomic, assign) NSInteger count;

@end
@interface CommentExtModel : NSObject

@property (nonatomic, assign) NSInteger pagesize;

@property (nonatomic, assign) NSInteger cTime;

@end

@interface CommentDataModel : NSObject

@property (nonatomic, copy) NSString *isLike;

@property (nonatomic, copy) NSString *Id;

@property (nonatomic, copy) NSString *headImg;

@property (nonatomic, copy) NSString *device;

@property (nonatomic, copy) NSString *isPostBigv;

@property (nonatomic, copy) NSString *responseNum;

@property (nonatomic, copy) NSString *userId;

@property (nonatomic, copy) NSString *oTime;

@property (nonatomic, strong) NSArray<CommentDataSubcommentsModel *> *subComments;

@property (nonatomic, copy) NSString *likeNum;

@property (nonatomic, copy) NSString *nickname;

@property (nonatomic, copy) NSString *atUid;

@property (nonatomic, copy) NSString *content;

@end

@interface CommentDataSubcommentsModel : NSObject

@property (nonatomic, copy) NSString *atUid;

@property (nonatomic, copy) NSString *comment_id;

@property (nonatomic, copy) NSString *Id;

@property (nonatomic, copy) NSString *content;

@property (nonatomic, copy) NSString *oTime;

@property (nonatomic, copy) NSString *nickname;

@property (nonatomic, copy) NSString *userId;

@property (nonatomic, copy) NSString *headImg;

@property (nonatomic, copy) NSString *device;

@property (nonatomic, copy) NSString *isPostBigv;

@end

