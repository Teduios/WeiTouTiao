//
//  QuickReplyModel.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/8.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuickReplyModel.h"

@implementation QuickReplyModel

+ (NSDictionary *)objectClassInArray{
    return @{@"data":[QuickReplyDataModel class]};
}

@end

@implementation QuickReplyDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list":[QuickReplyDataListModel class]};
}

@end

@implementation QuickReplyExtModel

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"cTime":@"c_time",
             @"interUrl":@"inter_url"
             };
}

@end

@implementation QuickReplyDataListModel

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"ackCode":@"ack_code",
             @"cateId":@"cate_id",
             @"ID":@"Id",
             @"imgSrc":@"img_src",
             @"isRec":@"is_rec",
             @"ncateId":@"ncate_id",
             @"srcId":@"src_id",
             @"srcLink":@"src_link",
             @"srcTitle":@"src_title",
             @"streamId":@"stream_id",
             @"topicId":@"topic_id",
             @"visitNum":@"visit_num"
             };
}

@end

@implementation QuickReplyDataListDisplayModel

@end
@implementation QuickReplyDataListActionModel

@end