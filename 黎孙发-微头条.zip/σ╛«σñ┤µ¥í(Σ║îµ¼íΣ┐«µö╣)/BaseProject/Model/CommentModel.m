//
//  CommentModel.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CommentModel.h"

@implementation CommentModel


+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [CommentDataModel class]};
}
@end
@implementation CommentExtModel

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"cTime":@"c_time"};
}

@end


@implementation CommentDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"subComments" : [CommentDataSubcommentsModel class]};
}

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"isLike":@"is_like",
             @"headImg":@"head_img",
             @"device":@"_device",
             @"isPostBigv":@"is_post_bigv",
             @"responseNum":@"response_num",
             @"userId":@"user_id",
             @"oTime":@"o_time",
             @"subComments":@"sub_comments",
             @"likeNum":@"like_num",
             @"atUid":@"at_uid"
             };
}

@end


@implementation CommentDataSubcommentsModel

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"atUid":@"at_uid",
             @"commentId":@"comment_id",
             @"oTime":@"o_time",
             @"userId":@"user_id",
             @"headImg":@"head_img",
             @"device":@"_device",
             @"isPostBigv":@"is_post_bigv"
             };
}

@end


