//
//  VideoModel.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoModel.h"

@implementation VideoModel


+ (NSDictionary *)objectClassInArray{
    return @{
             @"videoSidList" : [VideoSidListModel class],
             @"videoList" : [VideolistModel class],
             @"VAP4BFE3U" : [VideolistModel class],
             @"VAP4BFR16" : [VideolistModel class],
             @"VAP4BG6DL" : [VideolistModel class],
             @"VAP4BGTVD" : [VideolistModel class]
             };
}
@end
@implementation VideoSidListModel

@end


@implementation VideolistModel

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"desc":@"description",
             @"m3u8URL":@"m3u8_url",
             @"m3u8HdURL":@"m3u8Hd_url",
             @"mp4URL":@"mp4_url",
             @"mp4HdURL":@"mp4Hd_url"
             };
}

@end


