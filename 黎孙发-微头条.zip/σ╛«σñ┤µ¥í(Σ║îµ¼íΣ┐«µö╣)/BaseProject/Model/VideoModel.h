//
//  VideoModel.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class VideoSidListModel,VideolistModel;
@interface VideoModel : BaseModel

@property (nonatomic, copy) NSString *videoHomeSid;

@property (nonatomic, strong) NSArray<VideoSidListModel *> *videoSidList;

@property (nonatomic, strong) NSArray<VideolistModel *> *videoList;

@property (nonatomic, strong) NSArray<VideolistModel *> *VAP4BFE3U;
@property (nonatomic, strong) NSArray<VideolistModel *> *VAP4BFR16;
@property (nonatomic, strong) NSArray<VideolistModel *> *VAP4BG6DL;
@property (nonatomic, strong) NSArray<VideolistModel *> *VAP4BGTVD;

@end
@interface VideoSidListModel : BaseModel

@property (nonatomic, copy) NSString *sid;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *imgsrc;

@end

@interface VideolistModel : BaseModel

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, copy) NSString *replyid;

@property (nonatomic, copy) NSString *mp4URL;

@property (nonatomic, assign) NSInteger playCount;

@property (nonatomic, copy) NSString *replyBoard;

@property (nonatomic, copy) NSString *vid;

@property (nonatomic, assign) NSInteger length;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *m3u8HdURL;

@property (nonatomic, copy) NSString *ptime;

@property (nonatomic, copy) NSString *cover;

@property (nonatomic, copy) NSString *videosource;

@property (nonatomic, copy) NSString *mp4HdURL;

@property (nonatomic, assign) NSInteger playersize;

@property (nonatomic, assign) NSInteger replyCount;

@property (nonatomic, copy) NSString *m3u8URL;

@end

