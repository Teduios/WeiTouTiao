//
//  HotModel.h
//  微头条
//
//  Created by apple-jd21 on 15/11/1.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

//hot
@class HotDataModel, HotExtModel;
@interface HotModel : BaseModel

@property (nonatomic, assign) BOOL status;
@property (nonatomic, strong) HotDataModel *data;
@property (nonatomic, strong) HotExtModel *ext;
@property (nonatomic, assign) double count;

@end

//data
@interface HotDataModel : BaseModel

@property (nonatomic, assign) double pageno;
@property (nonatomic, assign) double currtime;
@property (nonatomic, assign) double prevtime;
@property (nonatomic, assign) double nexttime;
@property (nonatomic, strong) NSString *currsign;
@property (nonatomic, strong) NSArray *list;
@property (nonatomic, strong) NSString *prevsign;
@property (nonatomic, strong) NSString *nextsign;
//排序中神回复模块中特有
@property (nonatomic, strong) NSString *field;

@end

//Ext
@interface HotExtModel : BaseModel

@property (nonatomic, assign) double trendingBorder;
@property (nonatomic, strong) NSString *interUrl;
@property (nonatomic, assign) double cTime;

@end

//data--> list
@class HotDataListActionModel, HotDataListImgPositionModel, HotDataListDisplayModel;
@interface HotDataListModel : BaseModel

@property (nonatomic, strong) NSString *cateId;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, assign) BOOL hasImage;
@property (nonatomic, strong) NSString *summary;
@property (nonatomic, strong) NSString *srcId;
@property (nonatomic, strong) NSString *ncateId;
@property (nonatomic, assign) double visitNum;
@property (nonatomic, assign) BOOL hasQuiz;
@property (nonatomic, assign) BOOL isTrending;
@property (nonatomic, strong) HotDataListActionModel *action;
@property (nonatomic, strong) NSString *pubtime;
@property (nonatomic, strong) NSString *imgSrc;
@property (nonatomic, assign) BOOL isOriginal;
@property (nonatomic, strong) HotDataListImgPositionModel *imgPosition;
@property (nonatomic, strong) NSString *hasAttr;
@property (nonatomic, assign) BOOL hasVideo;
@property (nonatomic, strong) NSString *ID;
@property (nonatomic, assign) double topicId;
@property (nonatomic, strong) HotDataListDisplayModel *display;
@property (nonatomic, assign) id srcLink;
@property (nonatomic, strong) NSString *ackCode;
@property (nonatomic, strong) NSString *srcTitle;
@property (nonatomic, strong) NSString *isRec;
@property (nonatomic, assign) BOOL isPromote;
@property (nonatomic, assign) BOOL isHot;

@end

//data--> list --> action
@interface HotDataListActionModel : BaseModel

@property (nonatomic, strong) NSString *target;
@property (nonatomic, strong) NSString *type;
@property (nonatomic, assign) id value;

@end

//data--> list --> img_position
@interface HotDataListImgPositionModel : BaseModel

@property (nonatomic, assign) double x;
@property (nonatomic, assign) double y;

@end


//data--> list --> display
@interface HotDataListDisplayModel : BaseModel

@property (nonatomic, strong) NSString *type;
@property (nonatomic, assign) double value;

@end

