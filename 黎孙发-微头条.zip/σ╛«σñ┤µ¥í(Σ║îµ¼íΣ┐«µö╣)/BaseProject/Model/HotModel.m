//
//  HotModel.m
//  微头条
//
//  Created by apple-jd21 on 15/11/1.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HotModel.h"

@implementation HotModel

@end

@implementation HotExtModel

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"cTime":@"c_time",
             @"interUrl":@"inter_url",
             @"trendingBorder":@"trending_border"
             };
}

@end

@implementation HotDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list":[HotDataListModel class]};
}

@end

@implementation HotDataListModel

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"ackCode":@"ack_code",
             @"cateId":@"cate_id",
             @"hasAttr":@"has_attr",
             @"hasImage":@"has_image",
             @"hasQuiz":@"has_quiz",
             @"hasVideo":@"has_video",
             @"imgPosition":@"img_position",
             @"imgSrc":@"img_src",
             @"isOriginal":@"is_original",
             @"isPromote":@"is_promote",
             @"isRec":@"is_rec",
             @"isTrending":@"is_trending",
             @"ncateId":@"ncate_id",
             @"srcId":@"src_id",
             @"srcLink":@"src_link",
             @"srcTitle":@"src_title",
             @"topicId":@"topic_id",
             @"visitNum":@"visit_num",
             @"ID":@"Id"
             };
}

@end

@implementation HotDataListImgPositionModel

@end

@implementation HotDataListDisplayModel

@end

@implementation HotDataListActionModel

@end
