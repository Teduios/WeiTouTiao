//
//  RankUserModel.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankUserModel.h"

@implementation RankUserModel
+ (NSDictionary *)objectClassInArray{
    return @{@"data":[RankUserDataModel class]};
}
@end

@implementation RankUserDataModel

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"headImg":@"head_img",
             @"isPostBigv":@"is_post_bigv",
             @"userId":@"user_id"
             };
}
@end

@implementation RankUserExtModel

@end