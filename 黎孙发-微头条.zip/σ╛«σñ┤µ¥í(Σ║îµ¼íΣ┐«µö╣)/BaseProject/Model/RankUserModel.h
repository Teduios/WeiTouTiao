//
//  RankUserModel.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class RankUserExtModel;
@interface RankUserModel : BaseModel
@property (nonatomic, assign) BOOL status;
@property (nonatomic, strong) NSArray *data;
@property (nonatomic, strong) RankUserExtModel *ext;
@property (nonatomic, assign) double count;
@end

@interface RankUserDataModel : BaseModel
@property (nonatomic, strong) NSString *icon;
@property (nonatomic, strong) NSString *nickname;
@property (nonatomic, assign) double width;
@property (nonatomic, assign) double rank;
@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *num;
@property (nonatomic, strong) NSString *headImg;
@property (nonatomic, strong) NSString *isPostBigv;
@end

@interface RankUserExtModel : BaseModel
@property (nonatomic, assign) double pagesize;
@end

