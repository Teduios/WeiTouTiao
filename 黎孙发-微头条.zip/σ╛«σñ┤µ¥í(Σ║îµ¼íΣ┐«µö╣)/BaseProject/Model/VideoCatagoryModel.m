//
//  VideoCatagoryModel.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCatagoryModel.h"

@implementation VideoCatagoryModel


+ (NSDictionary *)objectClassInArray{
    return @{
             @"VAP4BFE3U" : [VideoCatagorySidListModel class],
             @"VAP4BFR16" : [VideoCatagorySidListModel class],
             @"VAP4BG6DL" : [VideoCatagorySidListModel class],
             @"VAP4BGTVD" : [VideoCatagorySidListModel class]
             };
}
@end
@implementation VideoCatagorySidListModel

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{
             @"desc":@"description"
             };
}

@end


