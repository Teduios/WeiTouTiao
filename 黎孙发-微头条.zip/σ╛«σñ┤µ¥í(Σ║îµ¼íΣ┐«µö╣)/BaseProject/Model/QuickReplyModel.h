//
//  QuickReplyModel.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/8.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class QuickReplyExtModel;
@interface QuickReplyModel : BaseModel

@property (nonatomic, assign) BOOL status;
@property (nonatomic, strong) NSArray *data;
@property (nonatomic, strong) QuickReplyExtModel *ext;
@property (nonatomic, assign) double count;

@end

@interface QuickReplyExtModel : BaseModel

@property (nonatomic, assign) double cTime;
@property (nonatomic, strong) NSString *interUrl;

@end

@interface QuickReplyDataModel : BaseModel

@property (nonatomic, strong) NSString *field;
@property (nonatomic, strong) NSArray *list;

@end


@class QuickReplyDataListActionModel, QuickReplyDataListDisplayModel;
@interface QuickReplyDataListModel : BaseModel

@property (nonatomic, strong) NSString *streamId;
@property (nonatomic, strong) NSString *isRec;
@property (nonatomic, strong) NSString *srcId;
@property (nonatomic, assign) id srcLink;
@property (nonatomic, strong) NSString *ID;
@property (nonatomic, strong) QuickReplyDataListDisplayModel *display;
@property (nonatomic, strong) NSString *pubtime;
@property (nonatomic, assign) double topicId;
@property (nonatomic, strong) NSString *ackCode;
@property (nonatomic, strong) NSString *srcTitle;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *imgSrc;
@property (nonatomic, strong) NSString *summary;
@property (nonatomic, strong) QuickReplyDataListActionModel *action;
@property (nonatomic, strong) NSString *ncateId;
@property (nonatomic, assign) double visitNum;
@property (nonatomic, strong) NSString *cateId;

@end

@interface QuickReplyDataListActionModel : BaseModel

@property (nonatomic, strong) NSString *target;
@property (nonatomic, strong) NSString *type;
@property (nonatomic, assign) id value;

@end

@interface QuickReplyDataListDisplayModel : BaseModel

@property (nonatomic, strong) NSString *type;
@property (nonatomic, assign) double value;

@end
