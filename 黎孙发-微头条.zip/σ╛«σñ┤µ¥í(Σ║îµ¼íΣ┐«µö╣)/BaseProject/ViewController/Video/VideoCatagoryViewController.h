//
//  VideoCatagoryViewController.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoCatagoryViewController : UIViewController

- (instancetype)initWithSid:(NSString *)sid;
@property (nonatomic, strong) NSString *sid;

@end
