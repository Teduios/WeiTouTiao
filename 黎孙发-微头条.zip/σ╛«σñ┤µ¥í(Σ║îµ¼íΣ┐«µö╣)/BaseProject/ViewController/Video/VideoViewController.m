//
//  VideoViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewController.h"
#import "VideoCell.h"
#import "VideoViewModel.h"

#import "VideoCatagoryViewController.h"
#import "UMSocial.h"

//微信分享
//AppID：wx945b58aef3a271f0
//AppSecret: 0ae78dd42761fd9681b04833c79a857b

@interface VideoViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) VideoViewModel *videoVM;
@property (nonatomic, strong) UITableView *tableView;

@end

@implementation VideoViewController

- (VideoViewModel *)videoVM{
    if (!_videoVM ) {
        _videoVM = [VideoViewModel new];
    }
    return _videoVM;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[VideoCell class] forCellReuseIdentifier:@"VideoCell"];
//        _tableView.rowHeight = kWindowW*590/640;
        //去掉头部的section和脚步section的显示范围
//        _tableView.contentInset=UIEdgeInsetsMake(-1, 0, -10, 0);
//        _tableView.allowsSelection = NO;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.videoVM refreshDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.header endRefreshing];
            }];
        }];
        _tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            [self.videoVM getMoreDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.footer endRefreshing];
            }];
        }];
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView.header beginRefreshing];

    
}

#pragma mark - UITableViewDelegate, UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.videoVM.rowNumber;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    


    
    VideoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"VideoCell" forIndexPath:indexPath];
    
    cell.titleLabel.text = [self.videoVM titleForRow:indexPath.section];
    cell.descLabel.text = [self.videoVM descForRow:indexPath.section];
    [cell.coverImage setImageWithURL:[self.videoVM coverURLForRow:indexPath.section] placeholderImage:[UIImage imageNamed:@"video_cell_content_bg"]];
    cell.duraLabel.text = [self.videoVM durationForRow:indexPath.section];
    cell.playCountLabel.text = [self.videoVM playCountForRow:indexPath.section];
    cell.videoURL = [self.videoVM videoURLForRow:indexPath.section];
    NSString *shareText = [NSString stringWithFormat:@"%@ %@", cell.titleLabel.text, cell.videoURL];
    //防止按钮的事件叠加,添加之前先把之前的事件删除
    [cell.shareButton bk_removeEventHandlersForControlEvents:UIControlEventTouchUpInside];
    [cell.shareButton bk_addEventHandler:^(id sender) {
        //注意：分享到微信好友、微信朋友圈、微信收藏、QQ空间、QQ好友、来往好友、来往朋友圈、易信好友、易信朋友圈、Facebook、Twitter、Instagram等平台需要参考各自的集成方法
        [UMSocialSnsService presentSnsIconSheetView:self
                                             appKey:@"564af52467e58e8b310047ce"
                                          shareText:shareText
                                         shareImage:[UIImage imageWithData:[NSData
                            dataWithContentsOfURL:[self.videoVM coverURLForRow:indexPath.section]]]
                                    shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToTencent,UMShareToRenren,UMShareToDouban,UMShareToQQ,UMShareToWechatSession,UMShareToQQ,UMShareToWechatTimeline,UMShareToQzone,nil] delegate:self];
    } forControlEvents:UIControlEventTouchUpInside];
//    [cell.replyCountButton setTitle:[self.videoVM replyCountForRow:indexPath.section] forState:UIControlStateNormal];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    if (indexPath.section == 0) {
//        return kWindowW/4.0;
//    }
    return kWindowW*590/640;
}
//设置分区头和分区尾的高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
         return kWindowW/4.0;
    }
    return 5;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    //设置头部按钮
    if (section == 0) {
        return [self createHeaderView];
    }
    return nil;
}
/** 添加头部四个分类的按钮 */
- (UIView *)createHeaderView{
    UIView *view = [UIView new];
    view.backgroundColor = [UIColor whiteColor];
    
    /*------------第一个按钮和标签--------------*/
    UIButton *headButton0 = [UIButton buttonWithType:UIButtonTypeCustom];
    //按钮切成圆形(效率不是很高)
    headButton0.layer.cornerRadius = 20;
    headButton0.layer.masksToBounds = YES;
    UILabel *titleLabel0 = [UILabel new];
    titleLabel0.font = [UIFont systemFontOfSize:13];
    titleLabel0.textColor = [UIColor blackColor];
    [view addSubview:headButton0];
    [view addSubview:titleLabel0];
    [headButton0 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(10);
        make.left.mas_equalTo(20);
        make.size.mas_equalTo(CGSizeMake(40, 40));
    }];
    [titleLabel0 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(headButton0.mas_centerX);
        make.top.mas_equalTo(headButton0.mas_bottom).mas_equalTo(10);
    }];
    //第一个按钮
    [headButton0 setBackgroundImageForState:UIControlStateNormal withURL:[self.videoVM sidImgSrcURLForRow:0]];
    //第一个按钮的点击事件
    [headButton0 bk_addEventHandler:^(id sender) {
        VideoCatagoryViewController *vc = [[VideoCatagoryViewController alloc]initWithSid:[self.videoVM sidForRow:0]];
        //设置导航的隐藏标题
        self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:[self.videoVM sidTitleForRow:0] style:UIBarButtonItemStylePlain target:nil action:nil];
        [self.navigationController pushViewController:vc animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    titleLabel0.text = [self.videoVM sidTitleForRow:0];
    
    /*------------第二个按钮和标签--------------*/
    UIButton *headButton1 = [UIButton buttonWithType:UIButtonTypeCustom];
    //按钮切成圆形(效率不是很高)
    headButton1.layer.cornerRadius = 20;
    headButton1.layer.masksToBounds = YES;
    UILabel *titleLabel1 = [UILabel new];
    titleLabel1.font = [UIFont systemFontOfSize:13];
    [view addSubview:headButton1];
    [view addSubview:titleLabel1];
    [headButton1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(headButton0.mas_centerY);
        make.left.mas_equalTo(headButton0.mas_right).mas_equalTo((kWindowW-40*4-20-20)/3);
        make.size.mas_equalTo(CGSizeMake(40, 40));
    }];
    [titleLabel1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(headButton1.mas_centerX);
        make.top.mas_equalTo(headButton1.mas_bottom).mas_equalTo(10);
    }];
    //第二个按
    [headButton1 setBackgroundImageForState:UIControlStateNormal withURL:[self.videoVM sidImgSrcURLForRow:1]];
    //第二个按钮的点击事件
    [headButton1 bk_addEventHandler:^(id sender) {
        VideoCatagoryViewController *vc = [[VideoCatagoryViewController alloc]initWithSid:[self.videoVM sidForRow:1]];
        //设置导航的隐藏标题
        self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:[self.videoVM sidTitleForRow:1] style:UIBarButtonItemStylePlain target:nil action:nil];
        [self.navigationController pushViewController:vc animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    titleLabel1.text = [self.videoVM sidTitleForRow:1];
    
    /*------------第三个按钮和标签--------------*/
    UIButton *headButton2 = [UIButton buttonWithType:UIButtonTypeCustom];
    headButton2.layer.cornerRadius = 20;
    headButton2.layer.masksToBounds = YES;
    UILabel *titleLabel2 = [UILabel new];
    titleLabel2.font = [UIFont systemFontOfSize:13];
    [view addSubview:headButton2];
    [view addSubview:titleLabel2];
    [headButton2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(headButton1.mas_centerY);
        make.size.mas_equalTo(CGSizeMake(40, 40));
        make.left.mas_equalTo(headButton1.mas_right).mas_equalTo((kWindowW-40*4-20-20)/3);
    }];
    [titleLabel2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(headButton2.mas_centerX);
        make.top.mas_equalTo(headButton2.mas_bottom).mas_equalTo(10);
    }];
    //第三个按钮图片和标签文字
    [headButton2 setBackgroundImageForState:UIControlStateNormal withURL:[self.videoVM sidImgSrcURLForRow:2]];
    //第三个按钮的点击事件
    [headButton2 bk_addEventHandler:^(id sender) {
        VideoCatagoryViewController *vc = [[VideoCatagoryViewController alloc]initWithSid:[self.videoVM sidForRow:2]];
         //设置导航的隐藏标题
        self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:[self.videoVM sidTitleForRow:2] style:UIBarButtonItemStylePlain target:nil action:nil];
        [self.navigationController pushViewController:vc animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    titleLabel2.text = [self.videoVM sidTitleForRow:2];
    
    /*------------第四个按钮和标签--------------*/
    UIButton *headButton3 = [UIButton buttonWithType:UIButtonTypeCustom];
    //按钮切成圆形(效率不是很高)
    headButton3.layer.cornerRadius = 20;
    headButton3.layer.masksToBounds = YES;
    UILabel *titleLabel3 = [UILabel new];
    titleLabel3.font = [UIFont systemFontOfSize:13];
    [view addSubview:headButton3];
    [view addSubview:titleLabel3];
    //第四个按钮和标签的约束
    [headButton3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(headButton2.mas_centerY);
        make.left.mas_equalTo(headButton2.mas_right).mas_equalTo((kWindowW-40*4-20-20)/3);
        make.size.mas_equalTo(CGSizeMake(40, 40));
    }];
    [titleLabel3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(headButton3.mas_centerX);
        make.top.mas_equalTo(headButton3.mas_bottom).mas_equalTo(10);
    }];
    //第四个按钮图片
    [headButton3 setBackgroundImageForState:UIControlStateNormal withURL:[self.videoVM sidImgSrcURLForRow:3]];
    //第四个按钮的点击事件
    [headButton3 bk_addEventHandler:^(id sender) {
        VideoCatagoryViewController *vc = [[VideoCatagoryViewController alloc]initWithSid:[self.videoVM sidForRow:3]];
         //设置导航的隐藏标题
        self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:[self.videoVM sidTitleForRow:3] style:UIBarButtonItemStylePlain target:nil action:nil];
        [self.navigationController pushViewController:vc animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    titleLabel3.text = [self.videoVM sidTitleForRow:3];
    
    return view;
}


@end
