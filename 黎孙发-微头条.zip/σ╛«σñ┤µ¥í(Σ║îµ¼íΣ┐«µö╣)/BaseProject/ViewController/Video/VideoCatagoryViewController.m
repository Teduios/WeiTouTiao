//
//  VideoCatagoryViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCatagoryViewController.h"
#import "VideoCell.h"
#import "VideoCatagoryViewModel.h"
#import "UMSocial.h"

@interface VideoCatagoryViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) VideoCatagoryViewModel *videoCatagoryVM;
@property (nonatomic, strong) UITableView *tableView;

@end

@implementation VideoCatagoryViewController

- (instancetype)initWithSid:(NSString *)sid{
    if (self = [super init]) {
        self.sid = sid;
    }
    return self;
}

- (VideoCatagoryViewModel *)videoCatagoryVM{
    if (!_videoCatagoryVM) {
        _videoCatagoryVM = [[VideoCatagoryViewModel alloc]initWithSid:self.sid];
    }
    return _videoCatagoryVM;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = kWindowW*590/640;
        _tableView.estimatedRowHeight = UITableViewAutomaticDimension;
        [_tableView registerClass:[VideoCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.videoCatagoryVM refreshDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.header endRefreshing];
            }];
        }];
        _tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            [self.videoCatagoryVM getMoreDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.footer endRefreshing];
            }];
        }];
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView.header beginRefreshing];
    
}

#pragma mark - UITableViewDelegate, UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.videoCatagoryVM.rowNumber;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    VideoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    cell.titleLabel.text = [self.videoCatagoryVM titleForRow:indexPath.section];
    cell.descLabel.text = [self.videoCatagoryVM descForRow:indexPath.section];
    [cell.coverImage setImageWithURL:[self.videoCatagoryVM coverURLForRow:indexPath.section] placeholderImage:[UIImage imageNamed:@"video_cell_content_bg"]];
    cell.duraLabel.text = [self.videoCatagoryVM durationForRow:indexPath.section];
    cell.playCountLabel.text = [self.videoCatagoryVM playCountForRow:indexPath.section];
    cell.videoURL = [self.videoCatagoryVM videoURLForRow:indexPath.section];
    [cell.shareButton bk_addEventHandler:^(id sender) {
        //注意：分享到微信好友、微信朋友圈、微信收藏、QQ空间、QQ好友、来往好友、来往朋友圈、易信好友、易信朋友圈、Facebook、Twitter、Instagram等平台需要参考各自的集成方法
        [UMSocialSnsService presentSnsIconSheetView:self appKey:@"564af52467e58e8b310047ce" shareText:@"你要分享的文字"shareImage:[UIImage imageNamed:@"icon.png"]
                                    shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToTencent,UMShareToRenren,UMShareToDouban,UMShareToQQ,UMShareToWechatSession,UMShareToQQ,UMShareToWechatTimeline,UMShareToQzone,nil] delegate:self];
    } forControlEvents:UIControlEventTouchUpInside];
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

//设置分区头和分区尾的高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 5;
}


@end
