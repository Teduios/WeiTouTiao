//
//  LoginAndRegisterViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LoginAndRegisterViewController.h"
#import "Factory.h"
#import "UMSocial.h"
#import "MeTableViewController.h"

@interface LoginAndRegisterViewController ()

@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UITextField *usernameTextField;
@property (nonatomic, strong) UITextField *passwordTextField;
@property (nonatomic, strong) UIButton *loginButton;
@property (nonatomic, strong) UIButton *registerButton;
@property (nonatomic, strong) UIButton *agreeButton;
@property (nonatomic, strong) UILabel *prototolLable;
@property (nonatomic, strong) UIButton *forgetPwdButton;
@property (nonatomic, strong) UIImageView *thirdPartyIV;
@property (nonatomic, strong) UIButton *sinaLoginBtn;
@property (nonatomic, strong) UIButton *wechatLoginBtn;
@property (nonatomic, strong) UIButton *qqLoginBtn;

//将第三方登录后发送过来的ToKen保存到UserDefault
@property (nonatomic, strong) NSUserDefaults *userDefault;
@property (nonatomic, strong) NSString  *libraryPath;

@property (nonatomic, strong) NSNotificationCenter *center;


@end

@implementation LoginAndRegisterViewController

- (NSNotificationCenter *)center{
    if (!_center) {
        _center = [NSNotificationCenter defaultCenter];
    }
    return _center;
}

- (NSUserDefaults *)userDefault{
    if (!_userDefault) {
        //单例模式
        _userDefault = [NSUserDefaults standardUserDefaults];
    }
    return _userDefault;
}

- (UIImageView *)imageView{
    if (!_imageView) {
        _imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"趣味内容分享平台"]];
        [self.view addSubview:_imageView];
        [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.left.mas_equalTo(0);
            make.top.mas_equalTo(64);
            make.height.mas_equalTo(kWindowW*300/640);
        }];
    }
    return _imageView;
}
- (UITextField *)usernameTextField{
    if (!_usernameTextField) {
        _usernameTextField = [[UITextField alloc]init];
        //向用户名的文本输入框，添加左视图
        UIImageView *leftViewN = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"用户名"]];
        leftViewN.frame = CGRectMake(0, 0, 20, 20);
        leftViewN.contentMode = UIViewContentModeScaleToFill;
        _usernameTextField.leftView = leftViewN;
        _usernameTextField.leftViewMode = UITextFieldViewModeAlways;
        _usernameTextField.borderStyle = UITextBorderStyleRoundedRect;
        _usernameTextField.placeholder = @"请输入手机号";
        [self.view addSubview:_usernameTextField];
        [_usernameTextField mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.imageView.mas_bottom);
            make.left.mas_equalTo(40);
            make.right.mas_equalTo(-40);
            make.height.mas_equalTo(30);
        }];
    }
    return _usernameTextField;
}
- (UITextField *)passwordTextField{
    if (!_passwordTextField) {
        _passwordTextField = [UITextField new];
        //向密码的文本输入框，添加右视图
        UIImageView *leftViewP = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"密码"]];
        leftViewP.frame = CGRectMake(0, 0, 20, 20);
        leftViewP.contentMode = UIViewContentModeScaleToFill;
        _passwordTextField.leftView = leftViewP;
        _passwordTextField.leftViewMode = UITextFieldViewModeAlways;
        _passwordTextField.borderStyle = UITextBorderStyleRoundedRect;
        _passwordTextField.placeholder = @"请输入密码（6-18位）";
        [self.view addSubview:_passwordTextField];
        [_passwordTextField mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.usernameTextField.mas_bottom).mas_equalTo(10);
            make.left.mas_equalTo(40);
            make.right.mas_equalTo(-40);
            make.height.mas_equalTo(30);
        }];
    }
    return _passwordTextField;
}
- (UIButton *)loginButton{
    if (!_loginButton) {
        _loginButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_loginButton setBackgroundImage:[UIImage imageNamed:@"不可登录"] forState:UIControlStateNormal];
        _loginButton.enabled = NO;
        [self.view addSubview:_loginButton];
        [_loginButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.passwordTextField.mas_bottom).mas_equalTo(20);
            make.right.mas_equalTo(-40);
            make.left.mas_equalTo(40);
            make.height.mas_equalTo(30);
        }];
    }
    return _loginButton;
}
- (UIButton *)registerButton{
    if (!_registerButton) {
        _registerButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_registerButton setBackgroundImage:[UIImage imageNamed:@"立即注册"] forState:UIControlStateNormal];
        [self.view addSubview:_registerButton];
        [_registerButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.loginButton.mas_bottom).mas_equalTo(10);
            make.right.mas_equalTo(-40);
            make.left.mas_equalTo(40);
            make.height.mas_equalTo(30);
        }];
    }
    return _registerButton;
}
- (UIButton *)agreeButton{
    if (!_agreeButton) {
        _agreeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_agreeButton setBackgroundImage:[UIImage imageNamed:@"同意icon"] forState:UIControlStateNormal];
        [self.view addSubview:_agreeButton];
        [_agreeButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.registerButton.mas_left);
            make.top.mas_equalTo(self.registerButton.mas_bottom).mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(15, 15));
        }];
    }
    return _agreeButton;
}
- (UILabel *)prototolLable{
    if (!_prototolLable) {
        _prototolLable = [UILabel new];
        _prototolLable.font = [UIFont systemFontOfSize:12];
        _prototolLable.textColor = [UIColor grayColor];
        _prototolLable.text = @"用户协议和隐私条例";
        [self.view addSubview:_prototolLable];
        [_prototolLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.agreeButton.mas_centerY);
            make.left.mas_equalTo(self.agreeButton.mas_right).mas_equalTo(2);
        }];
        
    }
    return _prototolLable;
}
- (UIButton *)forgetPwdButton{
    if (!_forgetPwdButton) {
        _forgetPwdButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_forgetPwdButton setTitle:@"忘记密码?" forState:UIControlStateNormal];
        [_forgetPwdButton setTitleColor:kRGBColor(80, 143, 225) forState:UIControlStateNormal];
        _forgetPwdButton.titleLabel.font = [UIFont systemFontOfSize:12];
        [self.view addSubview:_forgetPwdButton];
        [_forgetPwdButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.prototolLable.mas_centerY);
            make.right.mas_equalTo(self.registerButton.mas_right);
        }];
        
    }
    return _forgetPwdButton;
}
- (UIImageView *)thirdPartyIV{
    if (!_thirdPartyIV) {
        _thirdPartyIV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"第三方登录"]];
        [self.view addSubview:_thirdPartyIV];
        [_thirdPartyIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.registerButton.mas_left);
            make.right.mas_equalTo(self.registerButton.mas_right);
            make.top.mas_equalTo(self.prototolLable.mas_bottom).mas_equalTo(20);
            make.height.mas_equalTo(10);
        }];
        
    }
    return _thirdPartyIV;
}
- (UIButton *)sinaLoginBtn{
    if (!_sinaLoginBtn) {
        _sinaLoginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_sinaLoginBtn setBackgroundImage:[UIImage imageNamed:@"微博"] forState:UIControlStateNormal];
        [self.view addSubview:_sinaLoginBtn];
        [_sinaLoginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(70);
            make.top.mas_equalTo(self.thirdPartyIV.mas_bottom).mas_equalTo(20);
            make.size.mas_equalTo(CGSizeMake(35, 35));
        }];
        //实现点击新浪第三方登录
        [_sinaLoginBtn bk_addEventHandler:^(id sender) {
            UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina];
            
            snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
                
                // 获取微博用户名、uid、token等
                
                if (response.responseCode == UMSResponseCodeSuccess) {
                    
                    UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToSina];
                    
                    NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
                    //将获取到数据，写入用户本地
                    [self.userDefault setValue:snsAccount.userName forKey:@"userName"];
                    [self.userDefault setValue:snsAccount.usid forKey:@"usid"];
                    [self.userDefault setValue:snsAccount.accessToken forKey:@"accessToKen"];
                    [self.userDefault setValue:snsAccount.iconURL forKey:@"iconURL"];
                    
                    //确保数据已经写入沙盒
                    [self.userDefault synchronize];
                    
                    //通知更新
                    [self.center postNotificationName:@"update" object:self];
                    NSLog(@"开始发送通知");
                }});
            //回到根视图,即登录前的页面
            [self.navigationController popToRootViewControllerAnimated:YES];
            
        } forControlEvents:UIControlEventTouchUpInside];
        
        
    }
    return _sinaLoginBtn;
}
- (UIButton *)wechatLoginBtn{
    if (!_wechatLoginBtn) {
        _wechatLoginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_wechatLoginBtn setBackgroundImage:[UIImage imageNamed:@"微信"] forState:UIControlStateNormal];
        [self.view addSubview:_wechatLoginBtn];
        [_wechatLoginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-70);
            make.top.mas_equalTo(self.thirdPartyIV.mas_bottom).mas_equalTo(20);
            make.size.mas_equalTo(CGSizeMake(35, 35));
        }];
         //实现点击微信第三方登录
        [_wechatLoginBtn bk_addEventHandler:^(id sender) {
            UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToWechatSession];
            
            snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
                 // 获取微信用户名、uid、token等
                if (response.responseCode == UMSResponseCodeSuccess) {
                    
                    UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary]valueForKey:UMShareToWechatSession];
                    
                    NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
                    //将获取到数据，写入用户本地
                    [self.userDefault setValue:snsAccount.userName forKey:@"userName"];
                    [self.userDefault setValue:snsAccount.usid forKey:@"usid"];
                    [self.userDefault setValue:snsAccount.accessToken forKey:@"accessToKen"];
                    [self.userDefault setValue:snsAccount.iconURL forKey:@"iconURL"];
                    
                    
                    //确保数据已经写入沙盒
                    [self.userDefault synchronize];
                    //通知更新
                    [self.center postNotificationName:@"update" object:self];
                    NSLog(@"开始发送通知");
                }});
            //回到根视图,即登录前的页面
            [self.navigationController popToRootViewControllerAnimated:YES];
        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _wechatLoginBtn;
}
- (UIButton *)qqLoginBtn{
    if (!_qqLoginBtn) {
        _qqLoginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_qqLoginBtn setBackgroundImage:[UIImage imageNamed:@"qq"] forState:UIControlStateNormal];
        [self.view addSubview:_qqLoginBtn];
        [_qqLoginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.view.mas_centerX);
            make.centerY.mas_equalTo(self.sinaLoginBtn.mas_centerY);
            make.size.mas_equalTo(CGSizeMake(35, 35));
        }];
        [_qqLoginBtn bk_addEventHandler:^(id sender) {
            UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToQQ];
            
            snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
                
                //          获取微博用户名、uid、token等
                
                if (response.responseCode == UMSResponseCodeSuccess) {
                    
                    UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToQQ];
                    
                    NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
                    
                    //将获取到数据，写入用户本地
                    [self.userDefault setValue:snsAccount.userName forKey:@"userName"];
                    [self.userDefault setValue:snsAccount.usid forKey:@"usid"];
                    [self.userDefault setValue:snsAccount.accessToken forKey:@"accessToKen"];
                    [self.userDefault setValue:snsAccount.iconURL forKey:@"iconURL"];
                    
                    
                    //确保数据已经写入沙盒
                    [self.userDefault synchronize];
                    //通知更新
                    [self.center postNotificationName:@"update" object:self];
                    NSLog(@"开始发送通知");
                    
                }});
            //回到根视图,即登录前的页面
            [self.navigationController popToRootViewControllerAnimated:YES];
        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _qqLoginBtn;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.imageView.hidden = NO;
    self.usernameTextField.hidden = NO;
    self.passwordTextField.hidden = NO;
    self.loginButton.hidden = NO;
    self.registerButton.hidden = NO;
    self.agreeButton.hidden = NO;
    self.prototolLable.hidden = NO;
    self.forgetPwdButton.hidden = NO;
    self.thirdPartyIV.hidden = NO;
    self.sinaLoginBtn.hidden = NO;
    self.wechatLoginBtn.hidden = NO;
    self.qqLoginBtn.hidden = NO;
    
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

@end
