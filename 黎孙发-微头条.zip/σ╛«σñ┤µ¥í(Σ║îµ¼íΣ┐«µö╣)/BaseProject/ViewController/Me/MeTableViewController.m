//
//  MeTableViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MeTableViewController.h"


@interface MeTableViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *userIcon;
@property (weak, nonatomic) IBOutlet UIButton *userNameBtn;

@property (nonatomic, strong) NSString *lastName;
@property (nonatomic, strong) NSUserDefaults *userDefault;

@end

@implementation MeTableViewController

- (NSUserDefaults *)userDefault{
    if (!_userDefault) {
        //单例模式
        _userDefault = [NSUserDefaults standardUserDefaults];
    }
    return _userDefault;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //登出按钮
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"sign out" style:UIBarButtonItemStyleDone target:self action:@selector(signOut)];
   
     [self Refresh];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(Refresh) name:@"update" object:nil];
    NSLog(@"开始接受通知");
}

//登出警告框
- (void)signOut{
    NSString *title = NSLocalizedString(@"", nil);
    NSString *message = NSLocalizedString(@"确定要退出登录吗?", nil);
    NSString *cancelButtonTitle = NSLocalizedString(@"点错", nil);
    NSString *otherButtonTitle = nil;
    if ([self.userDefault stringForKey:@"userName"]) {
        title = NSLocalizedString(@"", nil);
        message = NSLocalizedString(@"确定要退出登录吗?", nil);
        cancelButtonTitle = NSLocalizedString(@"点错", nil);
        otherButtonTitle = NSLocalizedString(@"我意已决", nil);
    }else{
        title = NSLocalizedString(@"", nil);
        message = NSLocalizedString(@"对不起,你还没登陆呢!!!", nil);
        cancelButtonTitle = NSLocalizedString(@"去登陆", nil);
        otherButtonTitle = NSLocalizedString(@"", nil);
    }
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    // Create the actions.
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancelButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        DDLogVerbose(@"点击退出按钮,又取消了");
    }];
    
    UIAlertAction *otherAction = [UIAlertAction actionWithTitle:otherButtonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        DDLogVerbose(@"点击了退出登录");
        
        //删除本地用户登陆的数据
        [self.userDefault removeObjectForKey:@"userName"];
        [self.userDefault removeObjectForKey:@"usid"];
        [self.userDefault removeObjectForKey:@"accessToKen"];
        [self.userDefault removeObjectForKey:@"iconURL"];
        //刷新页面
        [self.tableView reloadData];
        
    }];
    
    // Add the actions.
    [alertController addAction:cancelAction];
    //登陆 与 没登陆 的警告框显示
    if ([self.userDefault stringForKey:@"userName"]) {
        [alertController addAction:otherAction];
    }
    
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];

    [self Refresh];


    
}



//刷新页面
- (void) Refresh
{
    NSLog(@"执行Refresh");
    //获取沙盒路径
    NSString *doc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *path = [doc stringByAppendingPathComponent:@"account.archive"];
    DDLogVerbose(@"path---------%@", path);
    
    //如果沙盒中的userName对应的值是空,就可以给视图上的按钮和头像赋值
    //通过KVC获取沙盒中的数据
    if ([self.userDefault stringForKey:@"userName"]) {
        [self.userNameBtn setTitle:[self.userDefault stringForKey:@"userName"] forState:UIControlStateNormal];
        [self.userIcon setImageWithURL:[NSURL URLWithString:[self.userDefault stringForKey:@"iconURL"]]];
        self.userIcon.layer.cornerRadius = 35;
        self.userIcon.layer.masksToBounds = YES;
        self.userNameBtn.enabled = YES;
    }else{
        [self.userNameBtn setTitle:@"点击登录" forState:UIControlStateNormal];
        [self.userIcon setImage:[UIImage imageNamed:@"无头像状态"]];
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 1;
    }
    return 9;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 1;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //点击高亮回到默认样式
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return (kWindowW * 0.8 * 400)/600;
    }
    return 44;
}


@end
