//
//  MainMenuViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MainMenuViewController.h"
#import "FirstViewController.h"

@interface MainMenuViewController ()

@end

@implementation MainMenuViewController


/** 内容页的首页应该是单例，每个进程都只是初始化一次 */
+ (UINavigationController *)standardMainMenuNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        MainMenuViewController *vc = [[MainMenuViewController alloc]initWithViewControllerClasses:[self viewControllerClasses] andTheirTitles:[self itemNames]];
        
        //通过设置values和keys向子控制器传值。(内部利用KVC实现)
        vc.keys = [self vcKeys];
        vc.values = [self vcValues];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}

/** 提供菜单栏的名字数组 */
+ (NSArray *)itemNames{
    return @[@"热门", @"美女", @"互动", @"萌宠", @"奇趣", @"爆笑", @"视频", @"生活", @"资讯"];
}
/** 提供菜单对应的控制器 */
+ (NSArray *)viewControllerClasses{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:[FirstViewController class]];
    }
    return [arr copy];
}
/** 提供每个vc对应的key值数组 */
+ (NSArray *)vcKeys{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:@"type"];
    }
    return [arr copy];
}
/** 提供每个vc对应的key值数组 */
+ (NSArray *)vcValues{
    NSMutableArray *arr = [NSMutableArray new];
    for (int i = 0; i < [self itemNames].count; i++) {
        [arr addObject:@(i)];
        NSLog(@"arr------%@",arr);
    }
    return [arr copy];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor redColor];
    self.title = @"首页";

}


@end
