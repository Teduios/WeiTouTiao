//
//  MenuViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/8.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MenuViewController.h"
#import "ScrollDisplayViewController.h"
#import "FirstViewController.h"

@interface MenuViewController ()<ScrollDisplayViewControllerDelegate>

@property (nonatomic, strong) ScrollDisplayViewController *sdVC;
/** 定义一个滚动视图 */
@property (nonatomic, strong) UIScrollView *scrollView;
/** 存放菜单上的按钮 */
@property (nonatomic, strong) NSMutableArray *buttons;
/** 用来保存当前的按钮 */
@property (nonatomic, strong) UIButton *currentButton;
/** 按钮的下划线视图 */
@property (nonatomic, strong) UIView *lineView;

@end

@implementation MenuViewController

- (UIScrollView *)scrollView{
    if (!_scrollView) {
        _scrollView = [UIScrollView new];
        //准备一个按钮名字数组
        NSArray *buttonNames = @[@"热门", @"美女", @"互动", @"萌宠", @"奇趣", @"爆笑", @"视频", @"生活", @"资讯"];
        
        //只想最新添加的按钮
        UIView *lastView = nil;
        for (int i = 0; i < buttonNames.count; i++) {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            [button setTitle:buttonNames[i] forState:UIControlStateNormal];
            [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [button setTitleColor:self.lineView.backgroundColor forState:UIControlStateSelected];
            button.titleLabel.font = [UIFont systemFontOfSize:15];
            
            //默认第一个按钮是当前的按钮
            if (i == 0) {
                self.currentButton = button;
                button.selected = YES;
            }
            [button bk_addEventHandler:^(UIButton *sender) {
                //如果当前按钮是点击状态，不需要任何操作
                //否则取消之前按钮的已点击转台，并把当前按钮设置为点击转台
                // sender 为刚刚点击了按钮
                if (self.currentButton != sender) {
                    self.currentButton.selected = NO;
                    sender.selected = YES;
                    self.currentButton = sender;
                    [self.lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
                        make.width.mas_equalTo(40);
                        make.height.mas_equalTo(2);
                        make.centerX.mas_equalTo(sender);
                        make.top.mas_equalTo(sender.mas_bottom).mas_equalTo(5);
                    }];
                    //当前页数
                    self.sdVC.currentPage = [_buttons indexOfObject:sender];
                }
            } forControlEvents:UIControlEventTouchUpInside];
            [self.scrollView addSubview:button];
            [button mas_makeConstraints:^(MASConstraintMaker *make) {
                make.size.mas_equalTo(CGSizeMake(40, 20));
                make.centerY.mas_equalTo(self.scrollView);
                if (lastView) {
                    make.left.mas_equalTo(lastView.mas_right).mas_equalTo(10);
                }else{
                    make.left.mas_equalTo(10);
                }
            }];
            //获取到最后一个按钮
            lastView = button;
            [self.buttons addObject:button];
        }
       //lastView是最后一个按钮，最后一个按钮的x轴 肯定是固定的，当设置按钮的右边缘距离父视图ContentView的右边缘距离10像素，那么滚动视图的内容区域就会被锁定
        [lastView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.scrollView.mas_right).mas_equalTo(-10);
        }];
        self.scrollView.showsHorizontalScrollIndicator = NO;
        [_scrollView addSubview:self.lineView];
        [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(40);
            make.height.mas_equalTo(2);
            UIButton *btn = self.buttons[0];
            make.centerX.mas_equalTo(btn);
            make.top.mas_equalTo(btn.mas_bottom).mas_equalTo(5);
        }];
       
    }
    return _scrollView;
}
- (NSMutableArray *)buttons{
    if (!_buttons) {
        _buttons = [NSMutableArray new];
    }
    return _buttons;
}
- (UIView *)lineView{
    if (!_lineView) {
        _lineView = [UIView new];
        _lineView.backgroundColor = kRGBColor(0, 122, 255);
    }
    return _lineView;
}

- (FirstViewController *)firstVCWithType:(MainPageType)type{
    FirstViewController *vc = [kStoryboard(@"Main") instantiateViewControllerWithIdentifier:@"FirstViewController"];
    vc.type = type;
    return vc;
}
- (ScrollDisplayViewController *)sdVC{
    if (!_sdVC) {
        NSArray *vcs = @[
                         [self firstVCWithType:MainPageTypeReMen],
                         [self firstVCWithType:MainPageTypeMeiNv],
                         [self firstVCWithType:MainPageTypeHuDong],
                         [self firstVCWithType:MainPageTypeMengChong],
                         [self firstVCWithType:MainPageTypeQiQu],
                         [self firstVCWithType:MainPageTypeBaoXiao],
                         [self firstVCWithType:MainPageTypeShiPin],
                         [self firstVCWithType:MainPageTypeShengHuo],
                         [self firstVCWithType:MainPageTypeZiXun]
                         ];
        _sdVC = [[ScrollDisplayViewController alloc]initWithViewControllers:vcs];
        _sdVC.autoCycle = NO;
        _sdVC.showPageControl = NO;
        _sdVC.delegate = self;
    }
    return _sdVC;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置导航栏的背景图片
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"导航栏蒙版"] forBarMetrics:UIBarMetricsDefault];
    //设置状态栏上相对与导航栏的颜色
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];

    [self addChildViewController:self.sdVC];
    [self.view addSubview:self.sdVC.view];
    [self.sdVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    
    [self.navigationController.navigationBar addSubview:self.scrollView];
    [self.scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.mas_equalTo(0);
        make.height.mas_equalTo(44);
    }];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.scrollView.hidden = NO;
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.scrollView.hidden = YES;
}

#pragma mark - ScrollDisplayViewControllerDelegate

- (void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController currentIndex:(NSUInteger)index{
    
    self.currentButton.selected = NO;
    self.currentButton = self.buttons[index];
    self.currentButton.selected = YES;
    [self.lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(40);
        make.height.mas_equalTo(2);
        make.centerX.mas_equalTo(self.currentButton);
        make.top.mas_equalTo(self.currentButton.mas_bottom).mas_equalTo(5);
    }];
    
}

@end
