//
//  DetailViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DetailViewController.h"
#import "CommentViewModel.h"
#import "ComnentCell.h"
#import "NSString+Extension.h"

@interface DetailViewController ()<UITableViewDelegate, UITableViewDataSource, UIWebViewDelegate>

@property (nonatomic, strong) NSString *streamId;
@property (nonatomic, strong) NSString *ackCode;

@property (nonatomic, strong) NSNotificationCenter *center;

@property (nonatomic, strong) UIWebView *webView;

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) CommentViewModel *commentVM;

//加载动画
@property (nonatomic, strong) UIActivityIndicatorView *activityIndicator;
@property (nonatomic, strong) UIImageView *aimaImageView;

@end

@implementation DetailViewController

- (CommentViewModel *)commentVM{
    if (!_commentVM) {
        _commentVM = [[CommentViewModel alloc]initWithStreamId:self.streamId];
    }
    return _commentVM;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
        [_tableView registerClass:[ComnentCell class] forCellReuseIdentifier:@"CommentCell"];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.size.mas_equalTo(CGSizeMake(kWindowW, kWindowH/2));
//            make.left.bottom.right.mas_equalTo(0);
//            make.edges.mas_equalTo(0);
            make.top.mas_equalTo(self.webView.mas_top);
            make.left.mas_equalTo(self.webView.mas_left);
            make.right.mas_equalTo(self.webView.mas_right);
        }];
        [self.commentVM refreshDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.localizedDescription];
            }else{
                [_tableView reloadData];
            }
        }];
        _tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            [self.commentVM getMoreDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.footer endRefreshing];
            }];
        }];
            
    }
    return _tableView;
}

- (id)initWithStreamId:(NSString *)streamId AckCode:(NSString *)ackCode{
    if (self = [super init]) {
        self.streamId = streamId;
        self.ackCode = ackCode;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.tableView.hidden = NO;
//    self.webView.hidden = NO;
    
    self.webView = [UIWebView new];
    self.webView.delegate = self;
//    self.webView.scrollView.scrollEnabled = NO;
    //预先加载url
    NSString *path = [NSString stringWithFormat:@"http://app.lerays.com/stream/app/view?stream_id=%@&_ack=%@&from=wtt-app", self.streamId, self.ackCode];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:path]];
    [self.webView loadRequest:request];
    [self.view addSubview:self.webView];
    [self.webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    //自定义左上角返回按钮
    [self goBack];
}



- (void)goBack{
    
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setImage:[UIImage imageNamed:@"btn_back_n"] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"btn_back_h"] forState:UIControlStateHighlighted];
    btn.frame = CGRectMake(0, 0, 45, 44);
    [btn bk_addEventHandler:^(id sender) {
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"show" object:nil];
        [self.navigationController popViewControllerAnimated:YES];
        
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *menuItem=[[UIBarButtonItem alloc] initWithCustomView:btn];
    //使用弹簧控件缩小菜单按钮和边缘距离
    UIBarButtonItem *spaceItem=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = -5;
    self.navigationItem.leftBarButtonItems = @[spaceItem,menuItem];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

#pragma mark - UITableViewDelegate, UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.commentVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //表格的第一个cell设置为webView;
//    if (indexPath.row == 0) {
//        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
//        [cell.contentView addSubview:self.webView];
//        [self.webView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.edges.mas_equalTo(0);
//        }];
//        return cell;
//    }else
if (indexPath.row == 0){
        UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
        cell.textLabel.text = @"热门评论";
        return cell;
    }else{
        ComnentCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommentCell"];
        
        [cell.iconImageView setImageWithURL:[self.commentVM iconURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"无头像状态"]];
        cell.nameLabel.text = [self.commentVM nickNameForRow:indexPath.row];
        cell.timeLabel.text = [self.commentVM commentTimeForRow:indexPath.row];
        cell.contentLabel.text = [self.commentVM commentContentForRow:indexPath.row];
        cell.likeNumLabel.text = [self.commentVM likeNumForRow:indexPath.row];
        return cell;
    }
}
//设置cell的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    if (indexPath.row == 0) {
//         /* 通过webview代理获取到内容高度后,将内容高度设置为cell的高 */
//        return self.webView.frame.size.height;
//    }else if (indexPath.row == 1){
//        return 44;
//    }else{
//        return UITableViewAutomaticDimension;
//    }
    if (indexPath.row == 0){
        return 44;
    }else{
        return UITableViewAutomaticDimension;
    }
}
//预测cell的高度,以做适配
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    if (indexPath.row == 0) {
//        /* 通过webview代理获取到内容高度后,将内容高度设置为cell的高 */
//        return self.webView.frame.size.height;
//    }else if (indexPath.row == 1){
//        return 44;
//    }else{
//        return UITableViewAutomaticDimension;
//    }
  if (indexPath.row == 0){
        return 44;
    }else{
        return UITableViewAutomaticDimension;
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

////表格头设置一个webView
//- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
//    
//    //获取搭配webview的高度
//    CGFloat height = [[self.webView stringByEvaluatingJavaScriptFromString:@"document.body.offsetHeight"] floatValue];
//    self.webView.frame = CGRectMake(self.webView.frame.origin.x, self.webView.frame.origin.y, kWindowW, height);
//    DDLogVerbose(@"---------%ld", self.webView.frame.size.height);
//    return self.webView.frame.size.height;
//}
//- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForHeaderInSection:(NSInteger)section{
//    
//    //获取搭配webview的高度
//    CGFloat height = [[self.webView stringByEvaluatingJavaScriptFromString:@"document.body.offsetHeight"] floatValue];
//    self.webView.frame = CGRectMake(self.webView.frame.origin.x, self.webView.frame.origin.y, kWindowW, height);
//    DDLogVerbose(@"---------%ld", self.webView.frame.size.height);
//    return self.webView.frame.size.height;
//}
////头视图
//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
//    UIView *view = [[UIView alloc]init];
//    self.webView = [UIWebView new];
//    self.webView.delegate = self;
//    self.webView.scrollView.scrollEnabled = NO;
//    //预先加载url
//    NSString *path = [NSString stringWithFormat:@"http://app.lerays.com/stream/app/view?stream_id=%@&_ack=%@&from=wtt-app", self.streamId, self.ackCode];
//    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:path]];
//    [self.webView loadRequest:request];
//    [view addSubview:self.webView];
//    return view;
//}

kRemoveCellSeparator

#pragma mark - UIWebViewDelegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    return YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
    //获取搭配webview的高度
    CGFloat height = [[self.webView stringByEvaluatingJavaScriptFromString:@"document.body.offsetHeight"] floatValue];
    self.webView.frame = CGRectMake(self.webView.frame.origin.x, self.webView.frame.origin.y, kWindowW, height);
    
    //动画结束前,刷新页面
    [self.tableView reloadData];

    //先加载动画3秒
//    [NSThread sleepForTimeInterval:3];
    //结束动画
    [self.aimaImageView stopAnimating];
    //动画结束时，释放加载掉图片
    [self.aimaImageView performSelector:@selector(setAnimationImages:) withObject:nil afterDelay:self.aimaImageView.animationDuration];
    UIView *view = (UIView*)[self.view viewWithTag:108];
    [view removeFromSuperview];
    
}
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    
    //创建背底全白View
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH)];
    [view setTag:108];
    [view setBackgroundColor:[UIColor whiteColor]];
    [view setAlpha:1.0];
    [self.view addSubview:view];
    
    //添加到view上
    self.aimaImageView = [[UIImageView alloc]init];
    [view addSubview:self.aimaImageView];
    [self.aimaImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(view);
        make.size.mas_equalTo(CGSizeMake(120, 120));
    }];
    
    //设置要播放的图片数组
    NSMutableArray *allImages = [NSMutableArray array];
    for (NSInteger i = 1; i < 63; i++) {
        NSString *imageName = [NSString stringWithFormat:@"加载动画_%ld", i];
        UIImage *image = [UIImage imageNamed:imageName];
        [allImages addObject:image];
    }
    //图片数据来源
    self.aimaImageView.animationImages = allImages;
    //动画重复次数
    self.aimaImageView.animationRepeatCount = 10;
    //设置动画的时长
    self.aimaImageView.animationDuration = 62*0.08;
    
    //开始动画
    [self.aimaImageView startAnimating];

}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error
{
    [self.aimaImageView stopAnimating];
    //动画结束时，释放加载掉图片
    [self.aimaImageView performSelector:@selector(setAnimationImages:) withObject:nil afterDelay:self.aimaImageView.animationDuration];
    UIView *view = (UIView*)[self.view viewWithTag:108];
    [view removeFromSuperview];
}


@end
