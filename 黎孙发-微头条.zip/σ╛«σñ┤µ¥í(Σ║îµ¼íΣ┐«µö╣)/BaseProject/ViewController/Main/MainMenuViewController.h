//
//  MainMenuViewController.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WMPageController.h>

@interface MainMenuViewController : WMPageController

/** 内容页的首页应该是单例，每个进程都只是初始化一次 */
+ (UINavigationController *)standardMainMenuNavi;

@end
