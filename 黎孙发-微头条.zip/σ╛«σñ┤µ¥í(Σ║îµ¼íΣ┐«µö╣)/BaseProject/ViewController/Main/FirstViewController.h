//
//  FirstViewController.h
//  微头条
//
//  Created by apple-jd21 on 15/10/31.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HotViewModel.h"

@interface FirstViewController : UICollectionViewController

//枚举值，确定该显示的是那一页
@property (nonatomic, assign) MainPageType type;

@end
