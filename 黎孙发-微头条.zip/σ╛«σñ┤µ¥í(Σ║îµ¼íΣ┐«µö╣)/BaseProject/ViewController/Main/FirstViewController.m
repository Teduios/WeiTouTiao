//
//  FirstViewController.m
//  微头条
//
//  Created by apple-jd21 on 15/10/31.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FirstViewController.h"
#import "HotViewModel.h"
#import "DetailViewController.h"


@interface FirstViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource>

@property (nonatomic, strong) HotViewModel *hotVM;

@end

@implementation FirstViewController

- (HotViewModel *)hotVM{
    if (!_hotVM) {
        _hotVM = [[HotViewModel alloc]initWithMainPageType:self.type];
    }
    return _hotVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.collectionView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.hotVM refreshDataCompletionHandle:^(NSError *error) {
            [self.collectionView reloadData];
            [self.collectionView.header endRefreshing];
            if (error) {
                [self showErrorMsg:error.localizedDescription];
            }
        }];
    }];
    [self.collectionView.header beginRefreshing];
    self.collectionView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.hotVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.collectionView reloadData];
            [self.collectionView.footer endRefreshing];
            if (error) {
                [self showErrorMsg:error.description];
            }
        }];
    }];
}


#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return self.hotVM.rowNumber;
    
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UIImageView *imageView = [UIImageView new];
    UILabel *titleLable = [UILabel new];
    UILabel *visitNumLabel = [UILabel new];
    UICollectionViewCell *cell = nil;
   
    cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"BigCell" forIndexPath:indexPath];
    imageView = (UIImageView *)[cell viewWithTag:1000];
    titleLable = (UILabel *)[cell viewWithTag:2000];
    visitNumLabel = (UILabel *)[cell viewWithTag:4000];
    if (indexPath.row % 7 == 0) {
        
    }else if (self.type == MainPageTypeHuDong){
        NSInteger num = [self.hotVM visitNumForRow:indexPath.row];
        visitNumLabel.text = [NSString stringWithFormat:@"%ld人已参与", num];
        if (num > 9999) {
            visitNumLabel.text = [NSString stringWithFormat:@"%ld万+人已参与", num/10000];
        }
        [imageView setImageWithURL:[self.hotVM iconForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"默认加载图片大"]];
        titleLable.text = [self.hotVM titleForRow:indexPath.row];
        return cell;
    }
    else{
        cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SmallCell" forIndexPath:indexPath];
        imageView = (UIImageView *)[cell viewWithTag:100];
        titleLable = (UILabel *)[cell viewWithTag:400];
        visitNumLabel = (UILabel *)[cell viewWithTag:200];
    }
    [imageView setImageWithURL:[self.hotVM iconForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"默认加载图片"]];
    titleLable.text = [self.hotVM titleForRow:indexPath.row];
    visitNumLabel.text = [NSString stringWithFormat:@"%ld", [self.hotVM visitNumForRow:indexPath.row]];
    
    return cell;
    
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSLog(@"index==%@", indexPath);
    DetailViewController *detailVC = [[DetailViewController alloc]initWithStreamId:[self.hotVM streamIdForRow:indexPath.row] AckCode:[self.hotVM ackCodeForRow:indexPath.row]];
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"首页" style:UIBarButtonItemStylePlain target:nil action:nil];
    
    [detailVC setHidesBottomBarWhenPushed:YES];
    
    [self.navigationController pushViewController:detailVC animated:YES];
    
}

#pragma mark - UICollectionViewDelegateFlowLayout

//每个cell的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSInteger width = (kWindowW-10) * 0.5;
    NSInteger height = width * 300 / 270;
    // 1 个大视图  6个小视图 一次规律排布
    if (indexPath.row % 7 == 0 || self.type == MainPageTypeHuDong) {
        width = kWindowW;
        height = width * 330 / 540.0;
    }
    return CGSizeMake(width, height);
}

//宏命令，让分割线左侧无空隙
kRemoveCellSeparator


@end
