//
//  DetailViewController.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

- (id)initWithStreamId:(NSString *)streamId AckCode:(NSString *)ackCode;

@end
