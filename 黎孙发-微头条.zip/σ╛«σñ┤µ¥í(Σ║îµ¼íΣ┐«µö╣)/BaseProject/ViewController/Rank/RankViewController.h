//
//  RankViewController.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RankContentViewModel.h"

@interface RankViewController : UIViewController

@property (nonatomic, assign) RankType type;

@end
