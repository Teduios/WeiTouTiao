//
//  RankViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankViewController.h"
#import "RankContentViewModel.h"
#import "QuickReplyViewModel.h"
#import "RankCell.h"
#import "QuickReplyCell.h"
#import "DetailViewController.h"

#import "RankMenuViewController.h"

@interface RankViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) RankContentViewModel *rankContentVM;
@property (nonatomic, strong) QuickReplyViewModel  *quickReplyVM;
@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSNotificationCenter *center;

@end

@implementation RankViewController

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[RankCell class] forCellReuseIdentifier:@"Cell"];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(UIEdgeInsetsMake(44, 0, 0, 0));
        }];
        
        _tableView.rowHeight = 65;
        _tableView.estimatedRowHeight = 65;
        
    }
    return _tableView;
}


- (RankContentViewModel *)rankContentVM{
    if (!_rankContentVM) {
        _rankContentVM = [[RankContentViewModel alloc]initWithRankType:_type];
    }
    return _rankContentVM;
}
- (QuickReplyViewModel *)quickReplyVM{
    if (!_quickReplyVM) {
        _quickReplyVM = [QuickReplyViewModel new];
    }
    return _quickReplyVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        if (self.type == RankTypeShenHuiFu) {
            [self.quickReplyVM refreshDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [self.tableView reloadData];
                }
                [self.tableView.header endRefreshing];
            }];
        }else{
            [self.rankContentVM refreshDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [self.tableView reloadData];
                }
                [self.tableView.header endRefreshing];
            }];
        }
    }];
    [self.tableView.header beginRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (self.type == RankTypeShenHuiFu) {
        return self.quickReplyVM.secNumber;
    }
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (self.type == RankTypeShenHuiFu) {
        
        return [self.quickReplyVM rowNumberForSection:section];
    }
    return self.rankContentVM.rowNumber;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    RankCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (self.type == RankTypeShenHuiFu) {
        
        [cell.iconImageView setImageWithURL:[self.quickReplyVM iconForIndexPath:indexPath] placeholderImage:[UIImage imageNamed:@"默认加载图片"]];
        cell.titleLabel.text = [self.quickReplyVM titleForIndexPath:indexPath];
        cell.numImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld", indexPath.row+1]];
        cell.eyeImageView.hidden = YES;
        
    }else{
        [cell.iconImageView setImageWithURL:[self.rankContentVM iconForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"默认加载图片"]];
        cell.titleLabel.text = [self.rankContentVM titleForRow:indexPath.row];
        cell.visitLabel.text = [self.rankContentVM visitNumForRow:indexPath.row];
        
        //设置前十排名的序号图片
        
        if (indexPath.row < 10) {
            cell.numImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld", indexPath.row+1]];
        }else{
            cell.numImageView.image = [UIImage imageNamed:@""];
        }
    }
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (self.type == RankTypeShenHuiFu) {
        UIView *headView = [UIView new];
        headView.backgroundColor = [UIColor whiteColor];
        UIImageView *numImageView = [UIImageView new];
        numImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@", [self.quickReplyVM fieldForSection:section]]];
        [headView addSubview:numImageView];
        [numImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(25, 25));
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(10);
        }];
        
        UILabel *label = [UILabel new];
        label.text = @"排行";
        label.font = [UIFont systemFontOfSize:15];
        [headView addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(numImageView.mas_right).mas_equalTo(10);
            make.centerY.mas_equalTo(numImageView.mas_centerY).mas_equalTo(0);
        }];
        return headView;
    }
    
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //2.向中心发送通知
    //name：通知名称
    //object：发送方对象是谁（通知是谁发送的）
    //userInofo：通知中携带的具体的信息
    [self.center postNotificationName:@"hide" object:self];
    
    DetailViewController *detailVC = nil;
    if (self.type == RankTypeShenHuiFu) {
        detailVC = [[DetailViewController alloc]initWithStreamId:[self.quickReplyVM streamIdForRow:indexPath] AckCode:[self.quickReplyVM ackCodeForRow:indexPath]];
    }else{
        detailVC = [[DetailViewController alloc]initWithStreamId:[self.rankContentVM streamIdForRow:indexPath.row] AckCode:[self.rankContentVM ackCodeForRow:indexPath.row]];
    }
    detailVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:detailVC animated:YES];
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (self.type == RankTypeShenHuiFu) {
        return 30;
    }
    return 5;
}

kRemoveCellSeparator

//测试：使用通知中心的方式，看是否能再跳转到详情页时，关闭上方的滚动条
//1.获取系统提供的通知中心对象(单例模式，不重复创建center)
- (NSNotificationCenter *)center{
    if (!_center) {
        _center = [NSNotificationCenter defaultCenter];
    }
    return _center;
}



@end
