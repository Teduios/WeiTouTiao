//
//  RankUserViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankUserViewController.h"

#import "RankUserCell.h"

@interface RankUserViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) RankUserViewModel *rankuserVM;
@property (nonatomic, strong) UITableView *tableView;

@end

@implementation RankUserViewController

- (RankUserViewModel *)rankuserVM{
    if (!_rankuserVM) {
        _rankuserVM = [[RankUserViewModel alloc]initWithRankUserType:_type];
    }
    return _rankuserVM;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [_tableView registerClass:[RankUserCell class] forCellReuseIdentifier:@"RankUserCell"];
        _tableView.rowHeight = 60;
        _tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.rankuserVM getDataFromNetCompleteHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.header endRefreshing];
            }];
        }];
        
    }
    return _tableView;
}


- (void)viewDidLoad{
    
    [self.tableView.header beginRefreshing];
}

#pragma mark - UITableViewDelegate, UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    DDLogVerbose(@"%ld", self.rankuserVM.rowNumber);
    return self.rankuserVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    RankUserCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RankUserCell"];
    
    if (indexPath.row < 10) {
        cell.rankImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld", indexPath.row+1]];
        cell.rankLabel.text = @"";
    }else{
        cell.rankImageView.image = [UIImage imageNamed:@""];
        cell.rankLabel.text = [NSString stringWithFormat:@"%ld", indexPath.row+1];
    }
    [cell.headView setImageWithURL:[self.rankuserVM headerIconURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"默认头像"]];
    if ([self.rankuserVM isPostBigvForRow:indexPath.row]) {
        cell.bigVImage.image = [UIImage imageNamed:@"大V"];
    }
    if (cell.bigVImage.image == nil) {
        cell.bigVImage.hidden = YES;
        [cell.nameLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(cell.headView.mas_right).mas_equalTo(5);
            make.centerY.mas_equalTo(0);
        }];
    }
    cell.nameLabel.text = [self.rankuserVM nicknameForRow:indexPath.row];
    cell.numLabel.text = [self.rankuserVM numForRow:indexPath.row];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
