//
//  QuickReplyViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuickReplyViewController.h"
#import "QuickReplyCell.h"
#import "QuickReplyViewModel.h"

@interface QuickReplyViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) QuickReplyViewModel *quickReplyVM;

@end

@implementation QuickReplyViewController

- (QuickReplyViewModel *)quickReplyVM{
    if (!_quickReplyVM) {
        _quickReplyVM = [QuickReplyViewModel new];
    }
    return _quickReplyVM;
}

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[QuickReplyCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.edges.mas_equalTo(UIEdgeInsetsMake(44, 0, 0, 0));
        }];
        _tableView.rowHeight = 65;
        _tableView.sectionHeaderHeight = 40;
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.quickReplyVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
        }];
    }];
    [self.tableView.header beginRefreshing];
    
}

#pragma mark - UITableViewDelegate, UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.quickReplyVM.secNumber;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.quickReplyVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    QuickReplyCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    [cell.iconImageView setImageWithURL:[self.quickReplyVM iconForIndexPath:indexPath] placeholderImage:[UIImage imageNamed:@"默认加载图片"]];
    cell.titleLabel.text = [self.quickReplyVM titleForIndexPath:indexPath];
    cell.rankIcon.image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld", indexPath.row+1]];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *headView = [UIView new];
    headView.backgroundColor = [UIColor whiteColor];
    UIImageView *numImageView = [UIImageView new];
    numImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@", [self.quickReplyVM fieldForSection:section]]];
    [headView addSubview:numImageView];
    [numImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(25, 25));
        make.centerY.mas_equalTo(0);
        make.left.mas_equalTo(10);
    }];
    
    UILabel *label = [UILabel new];
    label.text = @"排行";
    label.font = [UIFont systemFontOfSize:15];
    [headView addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(numImageView.mas_right).mas_equalTo(10);
        make.centerY.mas_equalTo(numImageView.mas_centerY).mas_equalTo(0);
    }];
    
    return headView;
}

@end
