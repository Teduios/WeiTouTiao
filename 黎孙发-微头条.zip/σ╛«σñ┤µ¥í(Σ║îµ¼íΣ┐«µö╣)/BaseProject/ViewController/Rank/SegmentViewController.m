//
//  SegmentViewController.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SegmentViewController.h"
#import "RankMenuViewController.h"
#import "RankUserViewController.h"
#import "UserMenuViewController.h"

@interface SegmentViewController ()

@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;


@end

@implementation SegmentViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    RankMenuViewController *rankVC = [[RankMenuViewController alloc]init];
    [self.view addSubview:rankVC.view];
    [rankVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    [self.segment addTarget:self action:@selector(didSelectSegment) forControlEvents:UIControlEventValueChanged];
//    self.navigationController.navigationBar.hidden = YES;
    
    //向通知中心注册需要监听某通知
    //Observer：那个对象成为观察者（成为观察者就能接受通知了）
    //selector：接受到了通知，那个方法被执行
    //name：监听那个通知
    //object：通知中的其他信息，很少用


}

- (void)didSelectSegment{
    if (self.segment.selectedSegmentIndex == 0) {
        RankMenuViewController *rankVC = [[RankMenuViewController alloc]init];
        [self.view addSubview:rankVC.view];
        [rankVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }else{
        UserMenuViewController *userVC = [[UserMenuViewController alloc]init];
        [self.view addSubview:userVC.view];
        [userVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }

}

- (instancetype)init{
    if (self = [super init]) {

      
    }
    return self;
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveNotification:) name:@"hide" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveShowNotification:) name:@"show" object:nil];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"hide"  object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"show" object:nil];
}

//通知一到达，自动执行此方法
- (void)receiveNotification:(NSNotification *)notification{
    self.tabBarController.tabBar.hidden = YES;
    self.navigationController.navigationBar.hidden = YES;
}

- (void)receiveShowNotification:(NSNotification *)notification{
    self.tabBarController.tabBar.hidden = NO;
    self.navigationController.navigationBar.hidden = NO;
}


@end
