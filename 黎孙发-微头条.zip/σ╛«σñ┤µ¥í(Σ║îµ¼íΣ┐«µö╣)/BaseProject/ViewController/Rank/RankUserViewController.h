//
//  RankUserViewController.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "RankUserViewModel.h"

@interface RankUserViewController : UIViewController

@property (nonatomic, assign) RankUserType type;

@end
