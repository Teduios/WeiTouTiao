//
//  WelcomeViewController.h
//  微头条
//
//  Created by apple-jd21 on 15/10/31.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WelcomeViewController : UIViewController

@end
