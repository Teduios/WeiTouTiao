//
//  WelcomeViewController.m
//  微头条
//
//  Created by apple-jd21 on 15/10/31.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WelcomeViewController.h"
#import "ScrollDisplayViewController.h"
#import "FirstViewController.h"
#import "TabBarViewController.h"

#define IMAGECOUNT 4

@interface WelcomeViewController ()<ScrollDisplayViewControllerDelegate>

@property (nonatomic, strong) ScrollDisplayViewController *sdVC;

@end

@implementation WelcomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSMutableArray *imageArr = [NSMutableArray new];
    for (int i = 0; i < IMAGECOUNT; i++) {
        [imageArr addObject:[NSString stringWithFormat:@"引导页面%d", i]];
    }
    _sdVC = [[ScrollDisplayViewController alloc]initWithImageNames:imageArr];
    //设置代理
    _sdVC.delegate = self;
    //设置不可循环滚动
    _sdVC.canCycle = NO;
    //设置不定时滚动
    _sdVC.autoCycle = NO;
    //设置pageControl的相关颜色
    _sdVC.pageControlCurrentColor = [UIColor blackColor];
    _sdVC.pageControlNormalColor = [UIColor lightGrayColor];
    [self addChildViewController:_sdVC];
    [self.view addSubview:_sdVC.view];
    [_sdVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    
}

#pragma mark - ScrollDisplayViewControllerDelegate

- (void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController didSelectedIndex:(NSInteger)index{
    NSLog(@"%ld", index);
    
    if (index == IMAGECOUNT - 1) {
        UITabBarController *tabBarVC = [self.storyboard instantiateViewControllerWithIdentifier:@"TabBarViewController"];
        [self presentViewController:tabBarVC animated:YES completion:nil];
    }
    
}


@end
