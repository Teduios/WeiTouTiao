//
//  QuickReplyNetManager.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "QuickReplyModel.h"

@interface QuickReplyNetManager : BaseNetManager

+ (id)getQucikReplyWithCompletionHandle:(void(^)(id model, NSError *error))completionHandle;

@end
