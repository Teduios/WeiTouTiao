//
//  HotNetManager.h
//  微头条
//
//  Created by apple-jd21 on 15/11/1.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "HotModel.h"

typedef NS_ENUM(NSUInteger, MainPageType) {
    MainPageTypeReMen,      //热门
    MainPageTypeMeiNv,      //美女
    MainPageTypeHuDong,     //互动
    MainPageTypeMengChong,  //萌宠
    MainPageTypeQiQu,       //奇趣
    MainPageTypeBaoXiao,    //爆笑
    MainPageTypeShiPin,     //视频
    MainPageTypeShengHuo,   //生活
    MainPageTypeZiXun       //资讯
};

@interface HotNetManager : BaseNetManager

//http://app.lerays.com/api/stream/hot?pubtime=0&cate_sign=null

+ (id)getMainPageType:(MainPageType)type NextTime:(NSInteger)nextTime NextSign:(NSString *)nextSign completionHandle:(void(^)(HotModel *model, NSError *error))completionHandle;

@end
