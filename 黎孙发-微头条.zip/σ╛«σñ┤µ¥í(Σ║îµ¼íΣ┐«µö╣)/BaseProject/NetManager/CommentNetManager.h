//
//  CommentNetManager.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "CommentModel.h"


@interface CommentNetManager : BaseNetManager

+ (id)getCommentDataWithStreamId:(NSString *)streamId pageId:(NSInteger)pageId CompletionHandle:(void(^)(id model, NSError *error))completionHandle;

@end
