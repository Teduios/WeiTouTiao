//
//  QuickReplyNetManager.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuickReplyNetManager.h"


@implementation QuickReplyNetManager

+ (id)getQucikReplyWithCompletionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path = @"http://app.lerays.com/api/stream/rank/quickreply";
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([QuickReplyModel objectWithKeyValues:responseObj], error);
    }];
}

@end
