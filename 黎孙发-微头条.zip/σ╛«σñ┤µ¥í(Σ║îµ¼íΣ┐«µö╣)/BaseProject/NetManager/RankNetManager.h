//
//  RankNetManager.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "HotModel.h"
#import "QuickReplyModel.h"

typedef NS_ENUM(NSUInteger, RankType) {
    RankTypeCuanHong,
    RankTypeZhouBang,
    RankTypeYueBang,
    RankTypeShenHuiFu
};

@interface RankNetManager : BaseNetManager

+ (id)getRankWithType:(RankType)type completionHandle:(void(^)(id model, NSError *error))completionHandle;

@end
