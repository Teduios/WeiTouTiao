//
//  HotNetManager.m
//  微头条
//
//  Created by apple-jd21 on 15/11/1.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HotNetManager.h"

//为发送的URL的参数定义成宏，方便以后修改
#define kMainPagePath   @"http://app.lerays.com/api/stream/list"
#define kCateType       @"cate_type":@"cate"

#define kSetCateList(string, dict) \
[dict setObject:string forKey:@"cate_list"];

@implementation HotNetManager

+ (id)getMainPageType:(MainPageType)type NextTime:(NSInteger)nextTime NextSign:(NSString *)nextSign completionHandle:(void (^)(HotModel *, NSError *))completionHandle{
    
    NSString *path = nil;
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithDictionary:@{@"pubtime":@(nextTime), @"cate_sign":nextSign, kCateType}];
    
    //根据不同的类型，设置对应的请求地址
    switch (type) {
            
        case MainPageTypeReMen:
            //因为热门这一页的发送的请求地址与其他的不同，所以要特殊处理
            path = @"http://app.lerays.com/api/stream/hot";
            return [self GET:path parameters:@{@"pubtime":@(nextTime), @"cate_sign":nextSign} completionHandler:^(id responseObj, NSError *error) {
                completionHandle([HotModel objectWithKeyValues:responseObj], error);
            }];
            break;
            
        case MainPageTypeMeiNv:
            kSetCateList(@"5", params);
            break;
            
        case MainPageTypeHuDong:
            kSetCateList(@"33", params);
            break;
            
        case MainPageTypeMengChong:
            kSetCateList(@"34", params);
            break;
            
        case MainPageTypeQiQu:
            kSetCateList(@"31", params);
            break;
            
        case MainPageTypeBaoXiao:
            kSetCateList(@"3", params);
            break;
            
        case MainPageTypeShiPin:
            kSetCateList(@"36", params);
            break;
            
        case MainPageTypeShengHuo:
            kSetCateList(@"35", params);
            break;
            
        case MainPageTypeZiXun:
            kSetCateList(@"32", params);
            break;
            
        default:
            DDLogVerbose(@"%s:type类型不匹配", __func__);
            break;
    }
    return [self GET:kMainPagePath parameters:params completionHandler:^(id responseObj, NSError *error) {
        completionHandle([HotModel objectWithKeyValues:responseObj], error);
    }];
    
}

@end
