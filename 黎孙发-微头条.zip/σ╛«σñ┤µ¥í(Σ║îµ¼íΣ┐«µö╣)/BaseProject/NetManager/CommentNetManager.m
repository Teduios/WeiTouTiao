//
//  CommentNetManager.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CommentNetManager.h"

@implementation CommentNetManager

+ (id)getCommentDataWithStreamId:(NSString *)streamId pageId:(NSInteger)pageId CompletionHandle:(void (^)(id, NSError *))completionHandle{
    
    NSString *path = [NSString stringWithFormat:@"http://app.lerays.com/api/stream/comment/list?pageno=%ld&v=2.7.2&stream_id=%@", pageId, streamId];
    
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([CommentModel objectWithKeyValues:responseObj], error);
    }];
    
}

@end
