//
//  RankUserNetManager.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "RankUserModel.h"

typedef NS_ENUM(NSUInteger, RankUserType) {
    RankUserTypeFenXiang,
    RankUserTypeTouGao,
    RankUserTypeDaV
};

@interface RankUserNetManager : BaseNetManager

+ (id)getRankUserInfoWithRankUserType:(RankUserType)type CompletionHandle:(void(^)(id model, NSError *error))completionHandle;

@end
