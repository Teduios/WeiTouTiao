//
//  VideoCatagoryNetManager.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "VideoModel.h"
#import "VideoCatagoryModel.h"

@interface VideoCatagoryNetManager : BaseNetManager

+ (id)getVideoCatagoryDataWithSid:(NSString *)sid index:(NSInteger)index CompletionHandle:(void(^)(id model, NSError *error))completionHandle;

@end
