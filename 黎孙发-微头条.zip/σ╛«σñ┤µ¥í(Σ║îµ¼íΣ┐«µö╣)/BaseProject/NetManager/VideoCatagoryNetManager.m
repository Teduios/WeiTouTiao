//
//  VideoCatagoryNetManager.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCatagoryNetManager.h"

@implementation VideoCatagoryNetManager

+ (id)getVideoCatagoryDataWithSid:(NSString *)sid index:(NSInteger)index CompletionHandle:(void (^)(id, NSError *))completionHandle{
    
    NSString *path = [NSString stringWithFormat:@"http://c.m.163.com/nc/video/list/%@/n/%ld-10.html", sid, index];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([VideoModel objectWithKeyValues:responseObj], error);
    }];
}


@end
