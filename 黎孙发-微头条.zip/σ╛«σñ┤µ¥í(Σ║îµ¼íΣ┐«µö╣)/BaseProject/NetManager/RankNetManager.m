//
//  RankNetManager.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankNetManager.h"

@implementation RankNetManager

+ (id)getRankWithType:(RankType)type completionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path = nil;
    switch (type) {
        case RankTypeCuanHong:
            path = @"http://app.lerays.com/api/stream/rank/trending";
            break;
            
        case RankTypeZhouBang:
            path = @"http://app.lerays.com/api/stream/rank/week";
            break;
            
        case RankTypeYueBang:
            path = @"http://app.lerays.com/api/stream/rank/month";
            break;
        
        case RankTypeShenHuiFu:
            path = @"http://app.lerays.com/api/stream/rank/quickreply";
            break;
            
        default:
            DDLogVerbose(@"%s:type类型不匹配", __func__);
            break;
    }
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([HotModel objectWithKeyValues:responseObj], error);
    }];
}



@end
