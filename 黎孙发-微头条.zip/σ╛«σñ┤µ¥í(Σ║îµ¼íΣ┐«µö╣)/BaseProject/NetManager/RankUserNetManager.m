//
//  RankUserNetManager.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankUserNetManager.h"


@implementation RankUserNetManager

+ (id)getRankUserInfoWithRankUserType:(RankUserType)type CompletionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path = nil;
    switch (type) {
        case RankUserTypeFenXiang:
            path = @"http://app.lerays.com/api/rank/ipn";
            break;
        case RankUserTypeTouGao:
            path = @"http://app.lerays.com/api/user/stream/post/rank";
            break;
        case RankUserTypeDaV:
            path = @"http://app.lerays.com/api/rank/tavg";
            break;
            
        default:
            break;
    }
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([RankUserModel objectWithKeyValues:responseObj], error);
    }];
}

@end
