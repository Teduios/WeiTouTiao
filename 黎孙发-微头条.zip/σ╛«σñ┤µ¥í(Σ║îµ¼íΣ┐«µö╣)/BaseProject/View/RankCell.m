//
//  RankCell.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankCell.h"

@implementation RankCell

- (UIImageView *)iconImageView{
    if (!_iconImageView) {
        _iconImageView = [UIImageView new];
   
    }
    return _iconImageView;
}
- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [UILabel new];
        _titleLabel.numberOfLines = 0;
        _titleLabel.font = [UIFont systemFontOfSize:15];
    }
    return _titleLabel;
}
- (UILabel *)visitLabel{
    if (!_visitLabel) {
        _visitLabel = [UILabel new];
        _visitLabel.font = [UIFont systemFontOfSize:12];
        _visitLabel.textAlignment = NSTextAlignmentRight;
        _visitLabel.textColor = [UIColor lightGrayColor];

    }
    return _visitLabel;
}
- (UIImageView *)numImageView{
    if (!_numImageView) {
        _numImageView = [UIImageView new];
        
    }
    return _numImageView;
}
/** 查看人数图标 */
- (UIImageView *)eyeImageView{
    if (!_eyeImageView) {
        _eyeImageView = [UIImageView new];
    }
    return _eyeImageView;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self.contentView addSubview:self.iconImageView];
        [_iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(80, 55));
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(10);
        }];
        
        [self.contentView addSubview:self.titleLabel];
        [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconImageView.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.top.mas_equalTo(self.iconImageView.mas_top);
        }];
        
        [self.contentView addSubview:self.visitLabel];
        [_visitLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.right.mas_equalTo(-10);
        }];
        
        [self.contentView addSubview:self.numImageView];
        [self.numImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(15, 12));
            make.left.mas_equalTo(self.iconImageView.mas_left);
            make.top.mas_equalTo(self.iconImageView.mas_top);
        }];
        
        self.eyeImageView.image = [UIImage imageNamed:@"display_1"];
        [self.contentView addSubview:self.eyeImageView];
        [self.eyeImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(15, 11));
            make.centerY.mas_equalTo(self.visitLabel);
            make.right.mas_equalTo(self.visitLabel.mas_left).mas_equalTo(-5);
        }];
        
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
