//
//  VideoCell.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCell.h"
//为播放视频引入的类库
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>

@implementation VideoCell

//初始一个播放器控制器，使用单例模式，限制同一时间只能播放一个视频
+ (AVPlayerViewController *)shareInstance{
    static AVPlayerViewController *playerVC = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        playerVC = [AVPlayerViewController new];
    });
    return playerVC;
}

/** 标题标签 */
- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [UILabel new];
        _titleLabel.font = [UIFont boldFlatFontOfSize:17];

    }
    return _titleLabel;
}
/** 详情标签 */
- (UILabel *)descLabel{
    if (!_descLabel) {
        _descLabel = [UILabel new];
        _descLabel.font = [UIFont systemFontOfSize:15];
        _descLabel.textColor = [UIColor grayColor];

    }
    return _descLabel;
}
/** 视频截图 */
- (UIImageView *)coverImage{
    if (!_coverImage) {
        _coverImage = [UIImageView new];
        _coverImage.userInteractionEnabled = YES;
    }
    return _coverImage;
}

/** 播放按钮 */
- (UIButton *)playButton{
    if (!_playButton) {
        _playButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_playButton setImage:[UIImage imageNamed:@"video_list_cell_big_icon"] forState:UIControlStateNormal];
        //点击按钮，播放视频
        [_playButton bk_addEventHandler:^(id sender) {
            //初始化一个播放器
            AVPlayer *player = [AVPlayer playerWithURL:self.videoURL];
            //开始播放视频
            [player play];
            [VideoCell shareInstance].player = player;
            //将播放控制器的视图添加到视频截图上
            [self.coverImage addSubview:[VideoCell shareInstance].view];
            [[VideoCell shareInstance].view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.center.mas_equalTo(self.coverImage);
                make.size.mas_equalTo(self.coverImage);
            }];
        } forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _playButton;
}

//如果正在播放视频的cell被复用了，需要将其cell上播放器上删除掉
- (void)prepareForReuse{
    [super prepareForReuse];
    
    //判断当前cell是否播放，如果有则删除
    if ([VideoCell shareInstance].view.superview == self.imageView || [VideoCell shareInstance].player != nil) {
        [[VideoCell shareInstance].view removeFromSuperview];
        [VideoCell shareInstance].player = nil;

    }
}

/** 时长图标 */
- (UIImageView *)duraImage{
    if (!_duraImage) {
        _duraImage = [UIImageView new];
        [_duraImage setImage:[UIImage imageNamed:@"video_list_cell_time"]];

    }
    return _duraImage;
}
/** 时长标签 */
- (UILabel *)duraLabel{
    if (!_duraLabel) {
        _duraLabel = [UILabel new];
        _duraLabel.font = [UIFont systemFontOfSize:15];
        _duraLabel.textColor = [UIColor grayColor];

    }
    return _duraLabel;
}
/** 播放图标 */
- (UIImageView *)playImage{
    if (!_playImage) {
        _playImage = [UIImageView new];
        [_playImage setImage:[UIImage imageNamed:@"video_list_cell_count"]];

    }
    return _playImage;
}
/** 播放次数标签 */
- (UILabel *)playCountLabel{
    if (!_playCountLabel) {
        _playCountLabel = [UILabel new];
        _playCountLabel.font = [UIFont systemFontOfSize:15];
        _playCountLabel.textColor = [UIColor grayColor];

    }
    return _playCountLabel;
}
/** 分享按钮 */
- (UIButton *)shareButton{
    if (!_shareButton) {
        _shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_shareButton setBackgroundImage:[UIImage imageNamed:@"video_category_share"] forState:UIControlStateNormal];
        [self.contentView addSubview:self.shareButton];
        /** 添加 分享按钮 约束*/
        [self.shareButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(33, 33));
            make.centerY.mas_equalTo(self.playCountLabel);
        }];
    }
    return _shareButton;
}
/** 评论次数按钮 */
//- (UIButton *)replyCountButton{
//    if (!_replyCountButton) {
//        _replyCountButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        [_replyCountButton setBackgroundImage:[UIImage imageNamed:@"video_category_comment"] forState:UIControlStateNormal];
//    }
//    return _replyCountButton;
//}


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //将空间添加到cell的视图上
        [self.contentView addSubview:self.titleLabel];
        [self.contentView addSubview:self.descLabel];
        
        [self.contentView addSubview:self.coverImage];
        [self.coverImage addSubview:self.playButton];
        
        [self.contentView addSubview:self.duraImage];
        [self.contentView addSubview:self.duraLabel];
        [self.contentView addSubview:self.playImage];
        [self.contentView addSubview:self.playCountLabel];
        
//        [self.contentView addSubview:self.replyCountButton];
        
        /** 添加 标题标签约束 */
        [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.right.mas_equalTo(10);
        }];
        
        /** 添加 详情标签 约束*/
        [self.descLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.titleLabel.mas_bottom).mas_equalTo(10);
            make.left.right.mas_equalTo(self.titleLabel);
        }];
        
        /** 添加 视频截图 约束*/
        [self.coverImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(kWindowW-20, (kWindowW-20)*345/600));
            make.top.mas_equalTo(_descLabel.mas_bottom).mas_equalTo(10);
            make.left.mas_equalTo(self.descLabel.mas_left);
        }];
        
        /** 添加 播放按钮 约束*/
        [self.playButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(50, 50));
            make.center.mas_equalTo(self.coverImage);
        }];
        
        /** 添加 时长图标 约束*/
        [self.duraImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(20, 20));
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(self.coverImage.mas_bottom).mas_equalTo(20);
        }];
        
        /** 添加 时长标签 约束*/
        [self.duraLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.duraImage);
            make.left.mas_equalTo(self.duraImage.mas_right).mas_equalTo(3);
        }];
        
        /** 添加 播放图标 约束*/
        [self.playImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.duraLabel);
            make.left.mas_equalTo(self.duraLabel.mas_right).mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(20, 20));
        }];

        /** 添加 播放次数标签 约束*/
        [self.playCountLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.playImage);
            make.left.mas_equalTo(self.playImage.mas_right).mas_equalTo(3);
        }];

        
        self.shareButton.hidden = NO;
        
        /** 添加 评论次数按钮 约束*/
//        [self.replyCountButton mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.centerY.mas_equalTo(self.playCountLabel);
//            make.right.mas_equalTo(self.shareButton.mas_left).mas_equalTo(-10);
//            make.size.mas_equalTo(CGSizeMake(77, 33));
//        }];
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
