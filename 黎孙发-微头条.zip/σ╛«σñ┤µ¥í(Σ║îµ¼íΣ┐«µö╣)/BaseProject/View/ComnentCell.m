//
//  ComnentCell.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ComnentCell.h"

@interface ComnentCell ()

@property (nonatomic, strong) UIImageView *likeImageView;

@end

@implementation ComnentCell

/** 头像图片视图 */
- (UIImageView *)iconImageView{
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc]init];
        _iconImageView.layer.cornerRadius = 20;
        _iconImageView.layer.masksToBounds = YES;
    }
    return _iconImageView;
}
/** 昵称标签 */
- (UILabel *)nameLabel{
    if (!_nameLabel) {
        _nameLabel = [UILabel new];
        _nameLabel.font = [UIFont systemFontOfSize:16];
        
    }
    return _nameLabel;
}
/** 时间标签 */
- (UILabel *)timeLabel{
    if (!_timeLabel) {
        _timeLabel = [UILabel new];
        _timeLabel.font = [UIFont systemFontOfSize:13];
        _timeLabel.textColor = [UIColor lightGrayColor];
    }
    return _timeLabel;
}
/** 评论内容标签 */
- (UILabel *)contentLabel{
    if (!_contentLabel) {
        _contentLabel = [UILabel new];
        _contentLabel.font = [UIFont systemFontOfSize:15];
        _contentLabel.numberOfLines = 5;
    }
    return _contentLabel;
}
/** 点赞人数 */
- (UILabel *)likeNumLabel{
    if (!_likeNumLabel) {
        _likeNumLabel = [UILabel new];
        _likeNumLabel.font = [UIFont systemFontOfSize:15];
        _likeNumLabel.textColor = [UIColor grayColor];
    }
    return _likeNumLabel;
}
- (UIImageView *)likeImageView{
    if (!_likeImageView) {
        _likeImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"赞21"]];
    }
    return _likeImageView;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self.contentView addSubview:self.iconImageView];
        [self.contentView addSubview:self.nameLabel];
        [self.contentView addSubview:self.timeLabel];
        [self.contentView addSubview:self.contentLabel];
        [self.contentView addSubview:self.likeNumLabel];
        [self.contentView addSubview:self.likeImageView];
        
        [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(40, 40));
            make.top.left.mas_equalTo(10);
        }];
        [self.nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(10);
            make.left.mas_equalTo(self.iconImageView.mas_right).mas_equalTo(10);
        }];
        [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.nameLabel.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(self.nameLabel.mas_left);
        }];
        [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.timeLabel.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(self.timeLabel.mas_left);
            make.right.mas_equalTo(self.contentView.mas_right).mas_equalTo(-5);
            make.bottom.mas_equalTo(self.contentView.mas_bottom).mas_equalTo(-5);
        }];
        [self.likeNumLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(20);
            make.right.mas_equalTo(-5);
        }];
        [self.likeImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.centerY.mas_equalTo(self.likeNumLabel.mas_centerY);
            make.right.mas_equalTo(self.likeNumLabel.mas_left).mas_equalTo(-5);
        }];
        
        
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
