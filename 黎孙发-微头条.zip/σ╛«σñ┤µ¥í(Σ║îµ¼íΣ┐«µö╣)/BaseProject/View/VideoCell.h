//
//  VideoCell.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoCell : UITableViewCell

/** 标题标签 */
@property (nonatomic, strong) UILabel *titleLabel;
/** 详情标签 */
@property (nonatomic, strong) UILabel *descLabel;
/** 视频截图 --- 图片*/
@property (nonatomic, strong) UIImageView *coverImage;
/** 播放按钮 */
@property (nonatomic, strong) UIButton *playButton;
/** 时长图标 */
@property (nonatomic, strong) UIImageView *duraImage;
/** 时长标签 */
@property (nonatomic, strong) UILabel *duraLabel;
/** 播放图标 */
@property (nonatomic, strong) UIImageView *playImage;
/** 播放次数标签 */
@property (nonatomic, strong) UILabel *playCountLabel;
///** 评论图标 */
//@property (nonatomic, strong) UIImageView *replyImage;
/** 评论次数按钮 */
//@property (nonatomic, strong) UIButton *replyCountButton;
/** 分享按钮 */
@property (nonatomic, strong) UIButton *shareButton;

//视频播放的URL
@property (nonatomic, strong) NSURL *videoURL;

/** 上方四个分类的id */
@property (nonatomic, strong) NSString *sid;


@end
