//
//  RankUserCell.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RankUserCell : UITableViewCell

/** 前十名排名图标 */
@property (nonatomic, strong) UIImageView *rankImageView;
@property (nonatomic, strong) UILabel *rankLabel;
/** 头像 */
@property (nonatomic, strong) UIImageView *headView;
/** 昵称标签 */
@property (nonatomic, strong) UILabel *nameLabel;
/** 分享或发表文章次数标签 */
@property (nonatomic, strong) UILabel *numLabel;
/** 大V 标识 */
@property (nonatomic, strong) UIImageView *bigVImage;

@end
