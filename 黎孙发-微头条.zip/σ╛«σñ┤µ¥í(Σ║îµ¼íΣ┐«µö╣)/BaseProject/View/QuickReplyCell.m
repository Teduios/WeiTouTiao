//
//  QuickReplyCell.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuickReplyCell.h"

@implementation QuickReplyCell

- (UIImageView *)iconImageView{
    if (!_iconImageView) {
        _iconImageView = [UIImageView new];
    }
    return _iconImageView;
}
- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [UILabel new];
        _titleLabel.numberOfLines = 0;
        _titleLabel.font = [UIFont systemFontOfSize:15];
    }
    return _titleLabel;
}
- (UIImageView *)rankIcon{
    if (!_rankIcon) {
        _rankIcon = [UIImageView new];
    }
    return _rankIcon;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.iconImageView];
        [self.contentView addSubview:self.titleLabel];
        [self.contentView addSubview:self.rankIcon];
        
        [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(80, 55));
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(10);
        }];
        [self.rankIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(15, 12));
            make.topMargin.mas_equalTo(self.iconImageView.mas_topMargin);
            make.leftMargin.mas_equalTo(self.iconImageView.mas_leftMargin);
        }];
        [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconImageView.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.topMargin.mas_equalTo(self.iconImageView.mas_topMargin);
        }];
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
