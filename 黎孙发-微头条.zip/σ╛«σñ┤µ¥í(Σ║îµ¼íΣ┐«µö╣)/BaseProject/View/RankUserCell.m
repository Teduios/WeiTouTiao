//
//  RankUserCell.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankUserCell.h"

@implementation RankUserCell

/** 前十名排名图标 */
- (UIImageView *)rankImageView{
    if (!_rankImageView) {
        _rankImageView = [UIImageView new];
        [self.contentView addSubview:_rankImageView];
        [_rankImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(20, 20));
            make.left.mas_equalTo(10);
            make.centerY.mas_equalTo(0);
        }];
        //把图像设置为圆的
        _rankImageView.layer.cornerRadius = 10;
    }
    return _rankImageView;
}
- (UILabel *)rankLabel{
    if (!_rankLabel) {
        _rankLabel = [UILabel new];
        _rankLabel.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:_rankLabel];
        [_rankLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.centerY.mas_equalTo(0);
        }];
    }
    return _rankLabel;
}
/** 头像 */
- (UIImageView *)headView{
    if (!_headView) {
        _headView = [UIImageView new];
        [self.contentView addSubview:_headView];
        [_headView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(50, 50));
            make.left.mas_equalTo(self.rankImageView.mas_right).mas_equalTo(10);
            make.centerY.mas_equalTo(0);
        }];
        _headView.layer.masksToBounds = YES;
        _headView.layer.cornerRadius = 25;
    }
    return _headView;
}
/** 大V 标识 */
- (UIImageView *)bigVImage{
    if (!_bigVImage) {
        _bigVImage = [UIImageView new];
        [self.contentView addSubview:_bigVImage];
        [_bigVImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(self.headView.mas_right).mas_equalTo(5);
        }];
    }
    return _bigVImage;
}
/** 昵称标签 */
- (UILabel *)nameLabel{
    if (!_nameLabel) {
        _nameLabel = [UILabel new];
        _nameLabel.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_nameLabel];
        [_nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.bigVImage.mas_right).mas_equalTo(5);
            make.centerY.mas_equalTo(0);
        }];
    }
    return _nameLabel;
}
/** 分享或发表文章次数标签 */
- (UILabel *)numLabel{
    if (!_numLabel) {
        _numLabel = [UILabel new];
        _numLabel.textAlignment = NSTextAlignmentRight;
        _numLabel.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_numLabel];
        [_numLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-10);
            make.centerY.mas_equalTo(0);
        }];
    }
    return _numLabel;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    }
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
