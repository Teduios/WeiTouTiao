//
//  RankCell.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RankCell : UITableViewCell

/** 新闻简图 */
@property (nonatomic, strong) UIImageView *iconImageView;
/** 新闻标题 */
@property (nonatomic, strong) UILabel *titleLabel;
/** 新闻排名的序号图 */
@property (nonatomic, strong) UIImageView *numImageView;
/** 查看人数 */
@property (nonatomic, strong) UILabel *visitLabel;
/** 查看人数图标 */
@property (nonatomic, strong) UIImageView *eyeImageView;

@end
