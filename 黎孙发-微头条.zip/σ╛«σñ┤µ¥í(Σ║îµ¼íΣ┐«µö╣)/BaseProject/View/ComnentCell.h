//
//  ComnentCell.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ComnentCell : UITableViewCell

/** 头像图片视图 */
@property (nonatomic, strong) UIImageView *iconImageView;
/** 昵称标签 */
@property (nonatomic, strong) UILabel *nameLabel;
/** 时间标签 */
@property (nonatomic, strong) UILabel *timeLabel;
/** 评论内容标签 */
@property (nonatomic, strong) UILabel *contentLabel;
/** 点赞人数 */
@property (nonatomic, strong) UILabel *likeNumLabel;

@end
