//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "WelcomeViewController.h"
#import "TabBarViewController.h"
#import "MainMenuViewController.h"
#import "FirstViewController.h"

#import "UMSocial.h"
#import "UMSocialWechatHandler.h"
#import "UMSocialQQHandler.h"


@interface AppDelegate ()

@end

@implementation AppDelegate

//友盟
//  564af52467e58e8b310047ce
//微信分享
//AppID：wx945b58aef3a271f0
//AppSecret: 0ae78dd42761fd9681b04833c79a857b

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self initializeWithApplication:application];
    
    //注册友盟Appkey
    [UMSocialData setAppKey:@"564af52467e58e8b310047ce"];
    //设置微信AppId、appSecret，分享url
    [UMSocialWechatHandler setWXAppId:@"wx945b58aef3a271f0" appSecret:@"0ae78dd42761fd9681b04833c79a857b" url:@"http://www.umeng.com/social"];
    //QQ授权登录
    [UMSocialQQHandler setQQWithAppId:@"1104539912" appKey:@"eFVgRits2fgf26Jf" url:@"http://www.umeng.com/social"];
    
    //1.手动初始化widdow
    self.window = [[UIWindow alloc]initWithFrame:[[UIScreen mainScreen] bounds]];
    
    //去info的路径
    NSDictionary *infoDict = [[NSBundle mainBundle] infoDictionary];
    
    /*
     版本号：version，build
     区别：
     version：正式发布版本号。用户只能看到version
     build：测试版本号，对于程序员来说的
     */
    //已运行过的版本号需要持久化处理，通常存储在userDefault中
    NSString *key = @"CFBundleShortVersionString";
    NSString *currentVersion = infoDict[key];
    NSString *runVersion = [[NSUserDefaults standardUserDefaults] stringForKey:key];
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    if (runVersion == nil || ![runVersion isEqualToString:currentVersion]) {
        //如果没运行过 或者版本号不一致，则显示欢迎页
        
        //xib的获取vc的方法
        //        WelcomeViewController *welcomVC = [[WelcomeViewController alloc]initWithNibName:@"WelcomeViewController" bundle:nil];
        
        //故事版的获取vc的方法
        UIViewController *welcomVC = [storyboard instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
        
        self.window.rootViewController = welcomVC;
        
        //保存新的版本号，防止下次运行在现实欢迎页
        [[NSUserDefaults standardUserDefaults] setValue:currentVersion forKey:key];
    }else{
        //        TabBarViewController *tabBarVC = [[TabBarViewController alloc]initWithNibName:@"TabBarViewController" bundle:nil];
        UITabBarController *tabBarVC = [storyboard instantiateViewControllerWithIdentifier:@"TabBarViewController"];
        self.window.rootViewController = tabBarVC;
    }
    [self.window makeKeyAndVisible];
    return YES;
}

//第三方分享----添加系统回调
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    return  [UMSocialSnsService handleOpenURL:url];
}
- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation{
    return  [UMSocialSnsService handleOpenURL:url];
}

@end
