//
//  RankUserViewModel.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "RankUserNetManager.h"

@interface RankUserViewModel : BaseViewModel

- (id)initWithRankUserType:(RankUserType)type;
@property (nonatomic, assign) RankUserType type;

/** 行数 */
@property (nonatomic, assign) NSInteger rowNumber;
/** 用户头像图片URL */
- (NSURL *)headerIconURLForRow:(NSInteger)row;
/** 是否是大V */
- (BOOL)isPostBigvForRow:(NSInteger)row;
/** 用户昵称 */
- (NSString *)nicknameForRow:(NSInteger)row;
/** 分享次数或投稿次数 */
- (NSString *)numForRow:(NSInteger)row;
/** 获取每页行数 */
@property (nonatomic, assign) NSInteger pageSize;

@end
