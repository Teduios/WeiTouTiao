//
//  HotViewModel.m
//  微头条
//
//  Created by apple-jd21 on 15/11/1.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HotViewModel.h"

@implementation HotViewModel

- (id)initWithMainPageType:(MainPageType)type{
    if (self = [super init]) {
        _type = type;
    }
    return self;
}

- (NSInteger)rowNumber{
    return self.dataArr.count;
}

- (HotDataListModel *)hotDataListModelForRow:(NSInteger)row{
    return self.dataArr[row];
}

- (NSURL *)iconForRow:(NSInteger)row{
    return [NSURL URLWithString:[self hotDataListModelForRow:row].imgSrc];
}
- (NSString *)titleForRow:(NSInteger)row{
    return [self hotDataListModelForRow:row].title;
}
- (NSInteger)visitNumForRow:(NSInteger)row{
    return [self hotDataListModelForRow:row].visitNum;
}
- (NSString *)streamIdForRow:(NSInteger)row{
    return [self hotDataListModelForRow:row].ID;
}
- (NSString *)ackCodeForRow:(NSInteger)row{
    return [self hotDataListModelForRow:row].ackCode;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    [HotNetManager getMainPageType:self.type NextTime:self.nextTime NextSign:self.nextSign completionHandle:^(HotModel *model, NSError *error) {
        if (self.currTime == 0 && [self.currSign isEqualToString:@"null"]) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.data.list];
        self.currTime = model.data.currtime;
        self.currSign = model.data.currsign;
        self.nextTime = model.data.nexttime;
        self.nextSign = model.data.nextsign;
        completionHandle(error);
    }];
}

- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    //发送第一条刷新信息时，url的参数都是 0 和 null
    self.nextTime = 0;
    self.nextSign = @"null";
    [self getDataFromNetCompleteHandle:completionHandle];
}

- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    [self getDataFromNetCompleteHandle:completionHandle];
}


@end
