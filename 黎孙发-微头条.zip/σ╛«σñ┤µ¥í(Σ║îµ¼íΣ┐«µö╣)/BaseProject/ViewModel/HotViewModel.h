//
//  HotViewModel.h
//  微头条
//
//  Created by apple-jd21 on 15/11/1.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "HotNetManager.h"

@interface HotViewModel : BaseViewModel

//定义一个可以选择类型的初始化方法，限制必须传入一个所选择的页面
- (id)initWithMainPageType:(MainPageType)type;
//搭配type属性
@property (nonatomic, assign) MainPageType type;

//行数
@property (nonatomic, assign) NSInteger rowNumber;

//定义一个属性，用于保存当前currTime，currSign
@property (nonatomic, assign) NSInteger currTime;
@property (nonatomic, strong) NSString *currSign;

//定义一个属性，用于保存当前nextTime，nextSign
@property (nonatomic, assign) NSInteger nextTime;
@property (nonatomic, strong) NSString *nextSign;

//对应行数据
- (NSURL *)iconForRow:(NSInteger)row;
- (NSString *)titleForRow:(NSInteger)row;
- (NSInteger)visitNumForRow:(NSInteger)row;
- (NSString *)streamIdForRow:(NSInteger)row;
- (NSString *)ackCodeForRow:(NSInteger)row;

@end
