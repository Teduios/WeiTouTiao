//
//  CommentViewModel.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CommentViewModel.h"

@interface CommentViewModel ()

@property (nonatomic, assign) NSInteger pageId;

@end

@implementation CommentViewModel

- (id)initWithStreamId:(NSString *)streamId{
    if (self = [super init]) {
        self.streamId = streamId;
    }
    return self;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [CommentNetManager getCommentDataWithStreamId:self.streamId pageId:self.pageId CompletionHandle:^(CommentModel *model, NSError *error) {
        if (self.pageId == 1) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.data];
        completionHandle(error);
    }];
}
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    self.pageId = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    self.pageId += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}

- (CommentDataModel *)getDataForRow:(NSInteger)row{
    return self.dataArr[row];
}

/** 行数 */
- (NSInteger)rowNumber{
    return self.dataArr.count;
}
/** 昵称 */
- (NSString *)nickNameForRow:(NSInteger)row{
    return [self getDataForRow:row].nickname;
}
/** 头像 */
- (NSURL *)iconURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self getDataForRow:row].headImg];
}
/** 评论时间 */
- (NSString *)commentTimeForRow:(NSInteger)row{
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:[self getDataForRow:row].oTime.integerValue];
    NSString *dateStr = [NSString stringWithFormat:@"%@", date];
    
    return [dateStr substringWithRange:NSMakeRange(5, 11)];
}
/** 评论内容 */
- (NSString *)commentContentForRow:(NSInteger)row{
    
    NSString *contentStr = [self getDataForRow:row].content;
    
    //查找是否有 <button class="weitt-at-button"  >简直是个奇葩，不解释不解释，那个美眉是怎么想不通的嫁给这样的男的。</button>
    NSRange r = [contentStr rangeOfString:@"<button"];
    if (r.location == NSNotFound) {
        return contentStr;
    }else{
        contentStr = [contentStr stringByReplacingOccurrencesOfString:@"<button class=\"weitt-at-button\"  >" withString:@""];
//        contentStr = [contentStr stringByReplacingOccurrencesOfString:@"<button class=\"weitt-at-button\" color=\"#444444\">" withString:@""];
        contentStr = [contentStr stringByReplacingOccurrencesOfString:@"</button>" withString:@""];
        return contentStr;
    }
    
}
/** 点赞的数量 */
- (NSString *)likeNumForRow:(NSInteger)row{
    return [self getDataForRow:row].likeNum;
}

@end
