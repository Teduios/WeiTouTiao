//
//  VideoCatagoryViewModel.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCatagoryViewModel.h"

@implementation VideoCatagoryViewModel

- (id)initWithSid:(NSString *)sid{
    if (self = [super init]) {
        self.sid = sid;
    }
    return self;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [VideoCatagoryNetManager getVideoCatagoryDataWithSid:self.sid index:self.index CompletionHandle:^(VideoModel *model, NSError *error) {
        if (self.index == 0) {
            [self.dataArr removeAllObjects];
        }
        if ([self.sid isEqualToString:@"VAP4BFE3U"]) {
            [self.dataArr addObjectsFromArray:model.VAP4BFE3U];
        }else if ([self.sid isEqualToString:@"VAP4BFR16"]){
            [self.dataArr addObjectsFromArray:model.VAP4BFR16];
        }else if ([self.sid isEqualToString:@"VAP4BG6DL"]){
            [self.dataArr addObjectsFromArray:model.VAP4BG6DL];
        }else if ([self.sid isEqualToString:@"VAP4BGTVD"]){
            [self.dataArr addObjectsFromArray:model.VAP4BGTVD];
        }else{
            DDLogVerbose(@"%s中类型错误", __func__);
        }
        completionHandle(error);
    }];
}
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    self.index = 0;
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    self.index += 10;
    [self getDataFromNetCompleteHandle:completionHandle];
}

- (VideolistModel *)listModelForRow:(NSInteger)row{
    return self.dataArr[row];
}

/** 行数 */
- (NSInteger)rowNumber{
    return self.dataArr.count;
}
/** 视频截图 */
- (NSURL *)coverURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self listModelForRow:row].cover];
}
/** 视频URL */
- (NSURL *)videoURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self listModelForRow:row].mp4URL];
}
/** 大标题 */
- (NSString *)titleForRow:(NSInteger)row{
    return [self listModelForRow:row].title;
}
/** 小标题 */
- (NSString *)descForRow:(NSInteger)row{
    return [self listModelForRow:row].desc;
}
/** 时长 */
- (NSString *)durationForRow:(NSInteger)row{
    NSInteger duration = [self listModelForRow:row].length;
    NSInteger min = duration / 60;
    NSInteger sec = duration % 60;
    return [NSString stringWithFormat:@"%02ld:%02ld", min, sec];
}
/** 播放次数 */
- (NSString *)playCountForRow:(NSInteger)row{
    NSInteger count = [self listModelForRow:row].playCount;
    if (count > 9999) {
        return [NSString stringWithFormat:@"%.1lf万", count/10000.0];
    }
    return [NSString stringWithFormat:@"%ld", count];
}
/** 评论次数 */
- (NSString *)replyCountForRow:(NSInteger)row{
    return [NSString stringWithFormat:@"%ld",[self listModelForRow:row].replyCount];
}

@end
