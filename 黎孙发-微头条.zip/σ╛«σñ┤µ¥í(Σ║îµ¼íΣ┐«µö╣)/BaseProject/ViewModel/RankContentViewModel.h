//
//  RankContentViewModel.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "RankNetManager.h"

@interface RankContentViewModel : BaseViewModel

//定义一个可以选择类型的初始化方法，限制必须传入一个所选择的页面
- (id)initWithRankType:(RankType)type;
//搭配type属性
@property (nonatomic, assign) RankType type;

@property (nonatomic, assign) NSInteger rowNumber;

- (NSURL *)iconForRow:(NSInteger)row;
- (NSString *)titleForRow:(NSInteger)row;
- (NSString *)visitNumForRow:(NSInteger)row;
- (NSString *)streamIdForRow:(NSInteger)row;
- (NSString *)ackCodeForRow:(NSInteger)row;

@end
