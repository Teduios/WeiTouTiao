//
//  VideoViewModel.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "VideoNetManager.h"

@interface VideoViewModel : BaseViewModel

//获取头部数据
/** 有多少个选项 */
@property (nonatomic, assign) NSInteger headerCount;
/** 有多少个选项 */
@property (nonatomic, strong) NSMutableArray *sidDataArray;
/** 选项头像 */
- (NSURL *)sidImgSrcURLForRow:(NSInteger)row;
/** 选项标题标签 */
- (NSString *)sidForRow:(NSInteger)row;
/** 标题 */
- (NSString *)sidTitleForRow:(NSInteger)row;

/** 页数 */
@property (nonatomic, assign) NSInteger index;
/** 行数 */
@property (nonatomic, assign) NSInteger rowNumber;
/** 视频截图 */
- (NSURL *)coverURLForRow:(NSInteger)row;
/** 视频URL */
- (NSURL *)videoURLForRow:(NSInteger)row;
/** 大标题 */
- (NSString *)titleForRow:(NSInteger)row;
/** 小标题 */
- (NSString *)descForRow:(NSInteger)row;
/** 时长 */
- (NSString *)durationForRow:(NSInteger)row;
/** 播放次数 */
- (NSString *)playCountForRow:(NSInteger)row;
/** 评论次数 */
- (NSString *)replyCountForRow:(NSInteger)row;


@end
