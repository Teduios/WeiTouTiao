//
//  QuickReplyViewModel.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"


@interface QuickReplyViewModel : BaseViewModel

/** 有多少个分区 */
@property (nonatomic, assign) NSInteger secNumber;
/** 每个分区有多少行 */
@property (nonatomic, assign) NSInteger rowNumber;
/** 对应分区的行数 */
- (NSInteger)rowNumberForSection:(NSInteger)section;

/** 获取排行类型 */
- (NSString *)fieldForSection:(NSInteger)section;
/** 图片 */
- (NSURL *)iconForIndexPath:(NSIndexPath *)indexPath;
/** 大标题 */
- (NSString *)titleForIndexPath:(NSIndexPath *)indexPath;
/** 获取跳转到详细也得url参数 streamId  */
- (NSString *)streamIdForRow:(NSIndexPath *)indexPath;
/** 获取跳转到详细也得url参数 Ack_Code */
- (NSString *)ackCodeForRow:(NSIndexPath *)indexPath;

@end
