//
//  RankContentViewModel.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankContentViewModel.h"

@implementation RankContentViewModel

- (id)initWithRankType:(RankType)type{
    if (self = [super init]) {
        _type = type;
    }
    return self;
}

- (NSInteger)rowNumber{
    return self.dataArr.count;
}

//因为排行页数据抓包下得到的属性，在hotModel全部都可以找得到，所以不需要重建模型层
- (HotDataListModel *)hotDataListForRow:(NSInteger)row{
    return self.dataArr[row];
}
- (NSURL *)iconForRow:(NSInteger)row{
    return [NSURL URLWithString:[self hotDataListForRow:row].imgSrc];
}
- (NSString *)titleForRow:(NSInteger)row{
    return [self hotDataListForRow:row].title;
}
- (NSString *)visitNumForRow:(NSInteger)row{
    NSInteger num = [self hotDataListForRow:row].visitNum;
    if (num > 9999) {
        return [NSString stringWithFormat:@"%ld万+", num / 10000];
    }
    
    return [NSString stringWithFormat:@"%ld", num];
}
- (NSString *)streamIdForRow:(NSInteger)row{
    return [self hotDataListForRow:row].ID;
}
- (NSString *)ackCodeForRow:(NSInteger)row{
    return [self hotDataListForRow:row].ackCode;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    [RankNetManager getRankWithType:self.type completionHandle:^(HotModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.data.list];
        completionHandle(error);
    }];
}

- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    [self getDataFromNetCompleteHandle:completionHandle];
    
}

@end
