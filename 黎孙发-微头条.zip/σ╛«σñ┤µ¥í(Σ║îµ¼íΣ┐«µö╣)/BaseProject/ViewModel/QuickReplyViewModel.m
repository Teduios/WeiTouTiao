//
//  QuickReplyViewModel.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/9.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuickReplyViewModel.h"
#import "QuickReplyNetManager.h"

@implementation QuickReplyViewModel

- (NSInteger)secNumber{
    return self.dataArr.count;
}
- (NSInteger)rowNumber{
    return [self dataForSection:0].list.count;
}
/** 对应分区的行数 */
- (NSInteger)rowNumberForSection:(NSInteger)section{
    return [self dataForSection:section].list.count;
}
- (QuickReplyDataModel *)dataForSection:(NSInteger)section{
    return self.dataArr[section];
}
- (QuickReplyDataListModel *)dataListForSection:(NSInteger)section Row:(NSInteger)row{
    return [self dataForSection:section].list[row];
}
- (NSString *)fieldForSection:(NSInteger)section{
    return [self dataForSection:section].field;
}
- (NSURL *)iconForIndexPath:(NSIndexPath *)indexPath{
    DDLogVerbose(@"--indexPath----------%@", indexPath);
    NSString *path = [self dataListForSection:indexPath.section Row:indexPath.row].imgSrc;
    return [NSURL URLWithString:path];
}
- (NSString *)titleForIndexPath:(NSIndexPath *)indexPath{
    return [self dataListForSection:indexPath.section Row:indexPath.row].title;
}
/** 获取跳转到详细也得url参数 streamId  */
- (NSString *)streamIdForRow:(NSIndexPath *)indexPath{
    return [self dataListForSection:indexPath.section Row:indexPath.row].streamId;
}
/** 获取跳转到详细也得url参数 Ack_Code */
- (NSString *)ackCodeForRow:(NSIndexPath *)indexPath{
    return [self dataListForSection:indexPath.section Row:indexPath.row].ackCode;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    [QuickReplyNetManager getQucikReplyWithCompletionHandle:^(QuickReplyModel *model, NSError *error) {
        if (!error) {
            [self.dataArr removeAllObjects];
            [self.dataArr addObjectsFromArray:model.data];
        }else{
            DDLogVerbose(@"%s", __func__);
        }
        completionHandle(error);
    }];
}
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    [self getDataFromNetCompleteHandle:completionHandle];
}


@end
