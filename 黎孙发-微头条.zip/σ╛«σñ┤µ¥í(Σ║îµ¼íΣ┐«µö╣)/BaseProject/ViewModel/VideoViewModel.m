//
//  VideoViewModel.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewModel.h"

@implementation VideoViewModel

- (NSMutableArray *)sidDataArray{
    if (!_sidDataArray) {
        _sidDataArray = [NSMutableArray new];
    }
    return _sidDataArray;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [VideoNetManager getVideoWithIndex:self.index completionHandle:^(VideoModel *model, NSError *error) {
        if (self.index == 0) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.videoList];
        [self.sidDataArray addObjectsFromArray:model.videoSidList];
        
        completionHandle(error);
    }];
}
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    self.index = 0;
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    self.index += 10;
    [self getDataFromNetCompleteHandle:completionHandle];
}

- (VideolistModel *)listModelForRow:(NSInteger)row{
    return self.dataArr[row];
}

/** 行数 */
- (NSInteger)rowNumber{
   return self.dataArr.count;
}
/** 视频截图 */
- (NSURL *)coverURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self listModelForRow:row].cover];
}
/** 视频URL */
- (NSURL *)videoURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self listModelForRow:row].mp4URL];
}
/** 大标题 */
- (NSString *)titleForRow:(NSInteger)row{
    return [self listModelForRow:row].title;
}
/** 小标题 */
- (NSString *)descForRow:(NSInteger)row{
    return [self listModelForRow:row].desc;
}
/** 时长 */
- (NSString *)durationForRow:(NSInteger)row{
    NSInteger duration = [self listModelForRow:row].length;
    NSInteger min = duration / 60;
    NSInteger sec = duration % 60;
    return [NSString stringWithFormat:@"%02ld:%02ld", min, sec];
}
/** 播放次数 */
- (NSString *)playCountForRow:(NSInteger)row{
    NSInteger count = [self listModelForRow:row].playCount;
    if (count > 9999) {
        return [NSString stringWithFormat:@"%.1lf万", count/10000.0];
    }
    return [NSString stringWithFormat:@"%ld", count];
}
/** 评论次数 */
- (NSString *)replyCountForRow:(NSInteger)row{
    return [NSString stringWithFormat:@"%ld",[self listModelForRow:row].replyCount];
}


- (VideoSidListModel *)sidListModelForRow:(NSInteger)row{
    return self.sidDataArray[row];
}
- (NSInteger)headerCount{
    return self.sidDataArray.count;
}
- (NSURL *)sidImgSrcURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self sidListModelForRow:row].imgsrc];
}
- (NSString *)sidTitleForRow:(NSInteger)row{
    return [self sidListModelForRow:row].title;
}
- (NSString *)sidForRow:(NSInteger)row{
    return [self sidListModelForRow:row].sid;
}

@end
