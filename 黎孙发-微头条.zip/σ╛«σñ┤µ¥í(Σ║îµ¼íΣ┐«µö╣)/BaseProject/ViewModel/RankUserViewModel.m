//
//  RankUserViewModel.m
//  BaseProject
//
//  Created by apple-jd21 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankUserViewModel.h"

@implementation RankUserViewModel

- (id)initWithRankUserType:(RankUserType)type{
    if (self = [super init]) {
        self.type = type;
    }
    return self;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    [RankUserNetManager getRankUserInfoWithRankUserType:self.type CompletionHandle:^(RankUserModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.data];
        self.pageSize = model.ext.pagesize;
        completionHandle(error);
    }];
}

- (RankUserDataModel *)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}

/** 行数 */
- (NSInteger)rowNumber{
    return self.dataArr.count;
}
/** 用户头像图片URL */
- (NSURL *)headerIconURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRow:row].headImg];
}
/** 是否是大V */
- (BOOL)isPostBigvForRow:(NSInteger)row{
    return [[self modelForRow:row].isPostBigv isEqualToString:@"1"];
}
/** 用户昵称 */
- (NSString *)nicknameForRow:(NSInteger)row{
    return [self modelForRow:row].nickname;
}
/** 分享次数或投稿次数 */
- (NSString *)numForRow:(NSInteger)row{
    
    //如果是在投稿达人的页面下，右边的次数标签是 **篇
    if (self.type == RankUserTypeTouGao) {
        return [NSString stringWithFormat:@"%@篇", [self modelForRow:row].num];
    }
    //如果是在分享达人，大V 的页面下，右边的次数标签是 **次
    //因为在大V秀中，右边的次数获取到是字符串类型的数字，且数字中有小数点，所以需要通过componentsSeparatedByString 字符串的分离方法提去小数点前的字符串（数字）
    NSString *numStr = [self modelForRow:row].num;
    NSArray *numArr = [numStr componentsSeparatedByString:@"."];
    return [NSString stringWithFormat:@"%@次", numArr[0]];
}

@end
