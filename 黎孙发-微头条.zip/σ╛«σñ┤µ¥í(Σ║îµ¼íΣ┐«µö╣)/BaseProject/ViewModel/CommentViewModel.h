//
//  CommentViewModel.h
//  BaseProject
//
//  Created by apple-jd21 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "CommentNetManager.h"

@interface CommentViewModel : BaseViewModel

- (id)initWithStreamId:(NSString *)streamId;
@property (nonatomic, strong) NSString *streamId;

/** 行数 */
@property (nonatomic, assign) NSInteger rowNumber;
/** 昵称 */
- (NSString *)nickNameForRow:(NSInteger)row;
/** 头像 */
- (NSURL *)iconURLForRow:(NSInteger)row;
/** 评论时间 */
- (NSString *)commentTimeForRow:(NSInteger)row;
/** 评论内容 */
- (NSString *)commentContentForRow:(NSInteger)row;
/** 点赞的数量 */
- (NSString *)likeNumForRow:(NSInteger)row;

@end
